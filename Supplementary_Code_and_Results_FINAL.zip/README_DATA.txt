GROUNDWATER AI SHORT COMMUNICATION - OPEN DATA PACKAGE
Downloaded 1 November 2026. Files are unmodified originals as published.

------------------------------------------------------------------
1. bgs/nhs.dat  (CSV text; open in Excel)
   Bangladesh DPHE/BGS National Hydrochemical Survey, 1998-99
   3,534 wells with coordinates; arsenic, well depth, 20+ elements.
   Source: https://www.bgs.ac.uk/groundwater/quality/groundwater-and-health/arsenic-contamination-of-groundwater/bangladesh-reports/
   Cite: BGS and DPHE (2001) Arsenic contamination of groundwater in
   Bangladesh. Kinniburgh DG, Smedley PL (eds). British Geological
   Survey Technical Report WC/00/19. BGS, Keyworth.
   Note: the first 4 rows are a header block; row 6 holds units.
   Values starting with "<" are below the detection limit.

2. araihazar/Dataset1.csv, araihazar/Dataset2.csv
   Groundwater arsenic, Araihazar upazila, Bangladesh
   Dataset2: >6,500 wells with coordinates, depth and year.
   Dataset1: 950 wells, field-kit vs lab arsenic.
   Source: https://www.hydroshare.org/resource/8e1373d87419447c945625af13f0a2ea
   License: CC BY.
   Cite: Jameel MY (2021) Groundwater arsenic measurements from
   Araihazar, Bangladesh. HydroShare. Plus the original studies:
   van Geen et al. (2003) and van Geen et al. (2014), as given on
   the HydroShare page.

3. usgs_as/Site_Information.csv, usgs_as/Water_Chemistry.csv
   Arsenic, manganese and pH in wells of the conterminous USA.
   Coordinates are Albers projection (metres), generalised to 1 km.
   Values with remark "<" are below the detection limit.
   Cite: Erickson ML, Hill ER, Wilson JT (2020) Arsenic, manganese, and
   pH groundwater quality data, selected well construction
   characteristics, and aquifer assignments for wells in the
   conterminous U.S. U.S. Geological Survey data release.
   https://doi.org/10.5066/P9JMUAPY

4. usgs_f/fluoride.csv
   Fluoride and major ions in 38,105 US wells, 1988-2017.
   No coordinate columns: lat/lon are decoded from the 15-digit USGS
   site ID (see scripts/load_data.py).
   Cite: McMahon PB (2020) Data for fluoride occurrence in United
   States groundwater. U.S. Geological Survey data release.
   https://doi.org/10.5066/P9CUPRIP

------------------------------------------------------------------
ALSO INCLUDED
   scripts/load_data.py      loads and harmonises all four datasets
   scripts/cv_experiment.py  random vs spatial cross-validation
   results/*.csv             full results, every seed and block size
   figs/                     preliminary figure

NOT INCLUDED
   Myanmar (Ayeyarwady Delta): site uses bot protection; not downloaded.
   Eawag global fluoride: package holds code and maps only, no raw
   well data; to be cited, not analysed.
