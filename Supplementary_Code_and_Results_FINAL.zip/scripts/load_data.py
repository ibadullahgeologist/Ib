"""Load and harmonise the open groundwater datasets used in the study.

Every loader returns a DataFrame with at least:
  x_km, y_km   projected coordinates in km (for spatial blocking)
  lat, lon     (when available)
  target       contaminant concentration (As in ug/L, F in mg/L)
  censored     True when the value was reported below detection
plus predictor columns listed in the returned `features`.
"""
import numpy as np
import pandas as pd
from pyproj import Transformer

DATA = "/home/claude/data"


def _to_km(lat, lon, epsg):
    t = Transformer.from_crs("EPSG:4326", f"EPSG:{epsg}", always_xy=True)
    x, y = t.transform(lon.values, lat.values)
    return np.asarray(x) / 1000, np.asarray(y) / 1000


def bangladesh_national():
    """DPHE/BGS National Hydrochemical Survey (1998-99), ~3,500 wells."""
    df = pd.read_csv(f"{DATA}/bgs/nhs.dat", skiprows=4, low_memory=False)
    df = df.iloc[1:]  # units row
    num = ["LAT_DEG", "LONG_DEG", "WELL_DEPTH", "YEAR_CONSTRUCTION", "As", "Ca",
           "Fe", "K_", "Mg", "Mn", "Na", "P_", "Si", "SO4", "Sr", "B_", "Ba"]
    raw_as = df["As"].astype(str).str.strip()
    for c in num:
        df[c] = pd.to_numeric(df[c].astype(str).str.replace("<", "").str.strip(),
                              errors="coerce")
    df["censored"] = raw_as.str.startswith("<")
    df = df.dropna(subset=["LAT_DEG", "LONG_DEG", "As"])
    df["lat"], df["lon"] = df["LAT_DEG"], df["LONG_DEG"]
    df["x_km"], df["y_km"] = _to_km(df.lat, df.lon, 32646)  # UTM 46N
    df["target"] = df["As"]
    df["depth"] = df["WELL_DEPTH"]
    feats = ["depth", "Ca", "Fe", "Mg", "Mn", "Na", "P_", "SO4", "Si", "K_"]
    return df, feats


def bangladesh_araihazar():
    """Araihazar upazila wells (van Geen et al.), >6,500 wells, ~25 km2."""
    df = pd.read_csv(f"{DATA}/araihazar/Dataset2.csv")
    df = df.rename(columns={"As_ppb": "target", "Latitude": "lat",
                            "Longitude": "lon", "Depth": "depth"})
    df = df.dropna(subset=["lat", "lon", "target"])
    df["censored"] = False
    df["x_km"], df["y_km"] = _to_km(df.lat, df.lon, 32646)
    feats = ["depth"]
    return df, feats


def usa_arsenic():
    """USGS conterminous-US As/Mn/pH (Erickson et al. 2020).
    Coordinates are Albers (m), generalised to 1 km."""
    site = pd.read_csv(f"{DATA}/usgs_as/Site_Information.csv")
    chem = pd.read_csv(f"{DATA}/usgs_as/Water_Chemistry.csv",
                       encoding="utf-8-sig", low_memory=False)
    chem = chem.dropna(subset=["As_Value"])
    chem["cens"] = chem["As_Remark"].astype(str).str.strip() == "<"
    # one record per well: most recent sample
    chem["Sample_Date"] = pd.to_datetime(chem["Sample_Date"], errors="coerce")
    chem = chem.sort_values("Sample_Date").groupby("SITE_ID").tail(1)
    df = chem.merge(site, on="SITE_ID", how="inner")
    df["target"] = df["As_Value"]
    df["censored"] = df["cens"]
    df["x_km"], df["y_km"] = df["XCoord"] / 1000, df["YCoord"] / 1000
    df["depth"] = pd.to_numeric(df["Depth_Value"], errors="coerce")
    df["pH"] = pd.to_numeric(df["pH_Value"], errors="coerce")
    df["Mn"] = pd.to_numeric(df["Mn_Value"], errors="coerce")
    feats = ["depth", "pH", "Mn"]
    return df, feats


def _nwis_latlon(site_id):
    """Decode lat/lon from a 15-digit NWIS site ID (DDMMSSDDDMMSSNN)."""
    s = str(site_id)
    if len(s) != 15 or not s.isdigit():
        return np.nan, np.nan
    lat = int(s[0:2]) + int(s[2:4]) / 60 + int(s[4:6]) / 3600
    lon = int(s[6:9]) + int(s[9:11]) / 60 + int(s[11:13]) / 3600
    if not (24 < lat < 50 and 66 < lon < 125):
        return np.nan, np.nan
    return lat, -lon


def usa_fluoride():
    """USGS fluoride in US groundwater (McMahon 2020), 38,105 wells."""
    df = pd.read_csv(f"{DATA}/usgs_f/fluoride.csv", dtype={"USGS_ID": str},
                     low_memory=False)
    ll = df["USGS_ID"].apply(_nwis_latlon)
    df["lat"] = [a for a, b in ll]
    df["lon"] = [b for a, b in ll]
    raw_f = df["F"].astype(str).str.strip()
    df["censored"] = raw_f.str.startswith("<")
    num = ["DEPTH", "O2", "PH", "TEMP", "CA", "MG", "K", "NA", "ALK", "CL", "F",
           "SIO2", "SO4", "TDS"]
    for c in num:
        df[c] = pd.to_numeric(df[c].astype(str).str.replace("<", "").str.strip(),
                              errors="coerce")
    df = df.dropna(subset=["lat", "lon", "F"])
    df["x_km"], df["y_km"] = _to_km(df.lat, df.lon, 5070)  # CONUS Albers
    df["target"] = df["F"]
    df["depth"] = df["DEPTH"]
    feats = ["depth", "PH", "TEMP", "CA", "MG", "NA", "ALK", "CL", "SO4", "SIO2"]
    return df, feats


LOADERS = {
    "Bangladesh (national) As": bangladesh_national,
    "Bangladesh (Araihazar) As": bangladesh_araihazar,
    "USA (national) As": usa_arsenic,
    "USA (national) F": usa_fluoride,
}
