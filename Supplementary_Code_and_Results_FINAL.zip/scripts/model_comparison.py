"""Does a different algorithm close the random-vs-spatial gap?
Five model families, same predictors and folds as Fig. 2a. Writes results/model_comparison.csv."""
import warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold, GroupKFold, StratifiedKFold
from sklearn.metrics import r2_score, roc_auc_score
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.neural_network import MLPRegressor, MLPClassifier
from xgboost import XGBRegressor, XGBClassifier
from lightgbm import LGBMRegressor, LGBMClassifier
from catboost import CatBoostRegressor, CatBoostClassifier
import load_data as ld
import pakistan_cv as pc

warnings.filterwarnings("ignore")
RES = "/home/claude/data/results"


def models(task, seed=0):
    imp = lambda: SimpleImputer(strategy="median", add_indicator=True)
    if task == "reg":
        return {
            "Random Forest": make_pipeline(imp(), RandomForestRegressor(300, min_samples_leaf=2, n_jobs=-1, random_state=seed)),
            "XGBoost": XGBRegressor(n_estimators=400, max_depth=6, learning_rate=0.05, subsample=0.8,
                                    colsample_bytree=0.8, n_jobs=-1, random_state=seed, tree_method="hist"),
            "LightGBM": LGBMRegressor(n_estimators=400, learning_rate=0.05, num_leaves=31, subsample=0.8,
                                      subsample_freq=1, colsample_bytree=0.8, random_state=seed, verbose=-1),
            "CatBoost": CatBoostRegressor(iterations=400, depth=6, learning_rate=0.05, random_seed=seed,
                                          verbose=0, thread_count=2),
            "Neural network (MLP)": make_pipeline(imp(), StandardScaler(), MLPRegressor(
                hidden_layer_sizes=(128, 64), early_stopping=True, max_iter=500, random_state=seed)),
        }
    return {
        "Random Forest": make_pipeline(imp(), RandomForestClassifier(300, min_samples_leaf=2, n_jobs=-1, random_state=seed)),
        "XGBoost": XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.05, subsample=0.8,
                                 colsample_bytree=0.8, random_state=seed),
        "LightGBM": LGBMClassifier(n_estimators=300, learning_rate=0.05, num_leaves=15, subsample=0.8,
                                   subsample_freq=1, colsample_bytree=0.8, random_state=seed, verbose=-1),
        "CatBoost": CatBoostClassifier(iterations=300, depth=4, learning_rate=0.05, random_seed=seed,
                                       verbose=0, thread_count=2),
        "Neural network (MLP)": make_pipeline(imp(), StandardScaler(), MLPClassifier(
            hidden_layer_sizes=(64, 32), early_stopping=True, max_iter=500, random_state=seed)),
    }


def block_groups(df, b, seed=0):
    g = (np.floor(df.x_km / b).astype(int).astype(str) + "_" +
         np.floor(df.y_km / b).astype(int).astype(str)).values
    ug = np.unique(g)
    fo = dict(zip(ug, np.random.default_rng(seed).integers(0, 5, len(ug))))
    return np.array([fo[v] for v in g])


def tasks():
    out = []
    df, feats = ld.usa_arsenic()
    out.append(("USA As", df, feats + ["x_km", "y_km"], np.log10(df.target.clip(lower=0).values + 1),
                "reg", block_groups(df, 400), "400 km blocks"))
    df, feats = ld.usa_fluoride()
    out.append(("USA F", df, feats + ["x_km", "y_km"], np.log10(df.target.values + 0.01),
                "reg", block_groups(df, 400), "400 km blocks"))
    df, _ = ld.bangladesh_national()
    out.append(("Bangladesh As", df, ["depth", "x_km", "y_km"], np.log10(df.target.clip(lower=0).values + 1),
                "reg", block_groups(df, 100), "100 km blocks"))
    df, _ = ld.bangladesh_araihazar()
    out.append(("Araihazar As", df, ["depth", "x_km", "y_km"], np.log10(df.target.values + 1),
                "reg", block_groups(df, 2), "2 km blocks"))
    p = pc.p
    out.append(("Pakistan F", p, ["x_km", "y_km", "depth"], np.log10(p["F (mg/l)"].values + 0.01),
                "reg", p.District.values, "leave-one-district-out"))
    out.append(("Pakistan As > 10 µg/L", p, ["x_km", "y_km", "depth"], (p["As µg"] > 10).astype(int).values,
                "clf", p.District.values, "leave-one-district-out"))
    return out


def run():
    import os
    f = f"{RES}/model_comparison.csv"
    rows = pd.read_csv(f).to_dict("records") if os.path.exists(f) else []
    done = {(r["dataset"], r["model"], r["scheme"]) for r in rows}
    for name, df, cols, y, task, groups, gname in tasks():
        X = df[cols].astype(float).reset_index(drop=True)
        for scheme in ["random", "spatial"]:
            if scheme == "random":
                cv = (StratifiedKFold if task == "clf" else KFold)(5, shuffle=True, random_state=0)
                splits = list(cv.split(X, y))
            else:
                k = len(np.unique(groups)) if "district" in gname else 5
                splits = list(GroupKFold(k).split(X, y, groups))
            for mname in models(task):
                if (name, mname, scheme) in done:
                    continue
                pred = np.zeros(len(y))
                for tr, te in splits:
                    m = models(task)[mname]
                    m.fit(X.iloc[tr], y[tr])
                    pred[te] = m.predict_proba(X.iloc[te])[:, 1] if task == "clf" else m.predict(X.iloc[te])
                score = roc_auc_score(y, pred) if task == "clf" else r2_score(y, pred)
                rows.append(dict(dataset=name, metric="AUC" if task == "clf" else "R2", model=mname,
                                 scheme=scheme, test_unit=("random wells" if scheme == "random" else gname),
                                 score=score))
                print(rows[-1], flush=True)
                pd.DataFrame(rows).to_csv(f"{RES}/model_comparison.csv", index=False)


if __name__ == "__main__":
    run()
