"""Shared figure style: journal print, Times-style serif, Nature-like proportions.

Text sizes requested in the figure scripts are scaled by FONT_SCALE with a floor of
MIN_PT, so every label is at least 7 pt at final print size (183 mm double column).
"""
import matplotlib as mpl
from matplotlib.text import Text

BLUE, ORANGE, AQUA, YELLOW, MAGENTA, VIOLET = (
    "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6")
INK, MUTED, GRID, RULE = "#000000", "#333333", "#e6e6e6", "#9a9a9a"
SEQ = ["#d9d8d3", "#f6b48f", "#eb6834", "#a53d14"]

SINGLE, DOUBLE = 3.5, 7.2  # 89 mm and 183 mm
FONT_SCALE, MIN_PT = 1.2, 7.0
SERIF = ["Times New Roman", "Liberation Serif", "Times", "STIXGeneral", "DejaVu Serif"]

_orig_set_fontsize = Text.set_fontsize


def _scaled_set_fontsize(self, fontsize):
    if isinstance(fontsize, (int, float)):
        fontsize = max(fontsize * FONT_SCALE, MIN_PT)
    return _orig_set_fontsize(self, fontsize)


def apply(scale=True):
    mpl.rcParams.update({
        "font.family": "serif", "font.serif": SERIF, "mathtext.fontset": "stix",
        "font.size": 8.5,
        "axes.titlesize": 7.2, "axes.labelsize": 8.5, "axes.titleweight": "bold",
        "axes.edgecolor": INK, "axes.labelcolor": INK, "axes.linewidth": 0.6,
        "axes.spines.top": False, "axes.spines.right": False,
        "xtick.color": INK, "ytick.color": INK,
        "xtick.labelsize": 8, "ytick.labelsize": 8,
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "legend.fontsize": 8, "legend.frameon": False,
        "savefig.dpi": 600, "figure.dpi": 150,
        "savefig.facecolor": "white", "figure.facecolor": "white",
        "pdf.fonttype": 42, "svg.fonttype": "none",
    })
    if scale:
        Text.set_fontsize = _scaled_set_fontsize
        Text.set_size = _scaled_set_fontsize


def panel(ax, letter, x=-0.12, y=1.04):
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=10,
            fontweight="bold", color=INK, va="bottom", ha="left")
