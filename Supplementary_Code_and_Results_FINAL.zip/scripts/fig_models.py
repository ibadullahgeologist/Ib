"""Supplementary Fig. S5: five model families, random vs held-out-region skill."""
import pandas as pd
import matplotlib.pyplot as plt
import style as S

S.apply()
d = pd.read_csv("/home/claude/data/results/model_comparison.csv")
tasks = ["USA As", "Araihazar As", "Bangladesh As", "USA F", "Pakistan F", "Pakistan As > 10 µg/L"]
models = ["Random Forest", "XGBoost", "LightGBM", "CatBoost", "Neural network (MLP)"]
fig, axes = plt.subplots(2, 3, figsize=(S.DOUBLE, 4.4))
for ax, t, L in zip(axes.flat, tasks, "abcdef"):
    sub = d[d.dataset == t]
    for i, m in enumerate(models[::-1]):
        r = sub[(sub.model == m) & (sub.scheme == "random")].score
        s = sub[(sub.model == m) & (sub.scheme == "spatial")].score
        if len(r) == 0 or len(s) == 0:
            continue
        r, s = r.iloc[0], s.iloc[0]
        ax.plot([s, r], [i, i], color=S.RULE, lw=1.8, zorder=1)
        ax.scatter(r, i, s=24, color=S.BLUE, edgecolor="white", lw=0.8, zorder=3)
        ax.scatter(s, i, s=24, color=S.ORANGE, edgecolor="white", lw=0.8, zorder=3)
    ax.set_yticks(range(len(models)))
    ax.set_yticklabels([m.replace("Neural network (MLP)", "Neural net (MLP)") for m in models[::-1]], fontsize=6.2)
    metric = sub.metric.iloc[0] if len(sub) else "R2"
    ax.axvline(0.5 if metric == "AUC" else 0, color=S.MUTED, lw=0.6, ls=":")
    unit = sub.test_unit[sub.scheme == "spatial"].iloc[0] if len(sub) else ""
    ax.set_title(f"{t}", loc="left", color=S.INK, fontsize=7.3)
    ax.set_xlabel(("ROC-AUC" if metric == "AUC" else "R²") + f"  (held-out: {unit.replace('leave-one-district-out', 'new district')})", fontsize=6)
    ax.tick_params(axis="y", length=0); ax.spines["left"].set_visible(False)
    ax.grid(axis="x", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
    S.panel(ax, L, x=-0.42)
fig.legend(handles=[plt.Line2D([], [], marker="o", ls="", color=S.BLUE, ms=5, label="random CV"),
                    plt.Line2D([], [], marker="o", ls="", color=S.ORANGE, ms=5, label="held-out region")],
           loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.0))
fig.tight_layout(rect=(0, 0, 1, 0.95), h_pad=1.4, w_pad=1.0)
for ext in ["png", "pdf"]:
    fig.savefig(f"/home/claude/data/figs/FigS5_model_comparison.{ext}")
print("ok")
