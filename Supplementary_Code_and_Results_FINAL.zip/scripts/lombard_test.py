"""Does the random-vs-regional gap persist with real mapping predictors?

Uses the model-input table of the published USGS national arsenic model
(Lombard 2021, doi:10.5066/P90RBJXS; Lombard et al. 2021 ES&T): 20,450 private wells
with ~70 mappable predictors (lithology, geologic units, surficial deposits, soil
C-horizon chemistry, recharge, precipitation, base-flow index, stream position,
tile drainage). Coordinates are not released, so spatial groups are the Level II
ecoregion indicators supplied in the table (wells with none of the listed
ecoregions form an 'other ecoregions' group). Ecoregion indicators are used only
for grouping, not as predictors.
Targets: As > 10 ug/L (bas10) and As > 5 ug/L (bas5). Metric: ROC-AUC.
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, LeaveOneGroupOut
from sklearn.metrics import roc_auc_score
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline

RES = "/home/claude/data/results"
d = pd.read_csv("/home/claude/data/usgs_lombard/AsModelInput.csv")
eco = [c for c in d.columns if c.startswith("na_")]
meta = ["bas1", "bas5", "bas10", "As3Cat", "spl1", "spl5", "spl10", "spl3cat"]
feats = [c for c in d.columns if c not in meta + eco]
grp = np.where(d[eco].sum(1) == 0, "other", d[eco].idxmax(1))
names = {"na_10.1": "Cold deserts", "na_11.1": "Mediterranean California",
         "na_12.1": "W. Sierra Madre piedmont", "na_13.1": "Upper Gila Mountains",
         "na_6.2": "Western Cordillera", "na_7.1": "Marine West Coast forest",
         "na_8.1": "Mixed wood plains", "na_8.2": "Central USA plains",
         "na_9.2": "Temperate prairies", "na_9.3": "W.-Central semi-arid prairies",
         "na_9.4": "S.-Central semi-arid prairies", "na_9.5": "Texas-Louisiana coastal plain",
         "na_9.6": "Tamaulipas-Texas semiarid plain", "other": "Other (eastern) ecoregions"}
X = d[feats].astype(float)


def model(kind, s):
    if kind == "XGBoost":
        return XGBClassifier(n_estimators=400, max_depth=6, learning_rate=0.05, subsample=0.8,
                             colsample_bytree=0.8, n_jobs=-1, random_state=s, tree_method="hist")
    return make_pipeline(SimpleImputer(strategy="median"),
                         RandomForestClassifier(400, min_samples_leaf=2, n_jobs=-1, random_state=s))


rows, per_region = [], []
for tgt in ["bas10", "bas5"]:
    ok = d[tgt].notna().values
    y = d.loc[ok, tgt].astype(int).values
    Xo, g = X[ok].reset_index(drop=True), grp[ok]
    for kind in ["XGBoost", "Random forest"]:
        for s in (range(3) if kind == "XGBoost" else [0]):
            pr = np.zeros(len(y))
            for tr, te in StratifiedKFold(5, shuffle=True, random_state=s).split(Xo, y):
                pr[te] = model(kind, s).fit(Xo.iloc[tr], y[tr]).predict_proba(Xo.iloc[te])[:, 1]
            rows.append(dict(target=tgt, model=kind, scheme="random 5-fold", seed=s, auc=roc_auc_score(y, pr)))
            pg = np.zeros(len(y))
            for tr, te in LeaveOneGroupOut().split(Xo, y, g):
                pg[te] = model(kind, s).fit(Xo.iloc[tr], y[tr]).predict_proba(Xo.iloc[te])[:, 1]
            rows.append(dict(target=tgt, model=kind, scheme="leave-one-ecoregion-out", seed=s,
                             auc=roc_auc_score(y, pg)))
            print(rows[-2], rows[-1], flush=True)
            if kind == "XGBoost" and s == 0:
                for gg in np.unique(g):
                    m = g == gg
                    if 0 < y[m].mean() < 1 and m.sum() >= 100:
                        per_region.append(dict(target=tgt, ecoregion=names[gg], n=int(m.sum()),
                                               share_exceed=y[m].mean(),
                                               auc_random=roc_auc_score(y[m], pr[m]),
                                               auc_heldout=roc_auc_score(y[m], pg[m])))
    # the published random hold-out split, as distributed (spl column TRUE = training)
    spl = {"bas10": "spl10", "bas5": "spl5"}[tgt]
    sp = d.loc[ok, spl].astype(str).str.upper().values
    tr, te = np.where(sp == "TRUE")[0], np.where(sp == "FALSE")[0]
    if len(te) > 0:
        p = model("XGBoost", 0).fit(Xo.iloc[tr], y[tr]).predict_proba(Xo.iloc[te])[:, 1]
        rows.append(dict(target=tgt, model="XGBoost", scheme="published random hold-out split",
                         seed=0, auc=roc_auc_score(y[te], p)))
        print(rows[-1], flush=True)
pd.DataFrame(rows).to_csv(f"{RES}/lombard_cv.csv", index=False)
pd.DataFrame(per_region).to_csv(f"{RES}/lombard_per_ecoregion.csv", index=False)
print(pd.DataFrame(rows).groupby(["target", "model", "scheme"]).auc.agg(["mean", "std"]).round(3))
print("n predictors:", len(feats), "groups:", pd.Series(grp).value_counts().to_dict())
