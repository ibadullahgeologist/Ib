"""Figure 2: apparent vs real skill, predictor leakage, uncertainty, transfer."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import style as S

S.apply()
R = "/home/claude/data/results"
OUT = "/home/claude/data/figs"

cv = pd.concat([pd.read_csv(f"{R}/cv_BangladeshnationalAs_BangladeshAraihazarAs.csv"),
                pd.read_csv(f"{R}/cv_USAnationalAs_USAnationalF.csv")])
pk = pd.read_csv(f"{R}/cv_pakistan.csv")
cf = pd.read_csv(f"{R}/conformal_coverage.csv")
tt = pd.read_csv(f"{R}/turkey_transfer.csv").groupby("test", sort=False).mean(numeric_only=True)

_b = pd.read_csv(f"{R}/cv_bangladesh_location_only.csv")
bd_loc = {"random": _b[_b.cv == "random"].r2.mean(),
          "100 km": _b[(_b.cv == "spatial") & (_b.block_km == 100)].r2.mean()}


def cvm(ds, fs, kind, block=0):
    d = cv[(cv.dataset == ds) & (cv.features == fs) & (cv.cv == kind) & (cv.block_km == block)]
    return d.r2.mean()


def pkm(target, fs, kind):
    d = pk[(pk.target == target) & (pk.features == fs) & (pk.cv == kind)]
    return d.score.mean()


fig = plt.figure(figsize=(S.DOUBLE, 5.9))
gs = fig.add_gridspec(2, 2, width_ratios=[1.25, 1], hspace=0.6, wspace=0.3)

# ---------------- (a) dumbbell: random vs held-out region R2
ax = fig.add_subplot(gs[0, 0])
rows = [
    ("USA As", cvm("USA (national) As", "chem+xy", "random"),
     cvm("USA (national) As", "chem+xy", "spatial", 400), "400 km blocks"),
    ("Araihazar As", cvm("Bangladesh (Araihazar) As", "chem+xy", "random"),
     cvm("Bangladesh (Araihazar) As", "chem+xy", "spatial", 2), "2 km blocks"),
    ("Bangladesh As", bd_loc["random"], bd_loc["100 km"], "100 km blocks"),
    ("USA F", cvm("USA (national) F", "chem+xy", "random"),
     cvm("USA (national) F", "chem+xy", "spatial", 400), "400 km blocks"),
    ("Pakistan NO₃", pkm("NO3", "location+depth", "random"),
     pkm("NO3", "location+depth", "district"), "new district"),
    ("Pakistan F", pkm("F", "location+depth", "random"),
     pkm("F", "location+depth", "district"), "new district"),
]
for i, (lab, r, s, b) in enumerate(rows[::-1]):
    ax.plot([s, r], [i, i], color=S.RULE, lw=2, zorder=1, solid_capstyle="round")
    ax.scatter(r, i, s=34, color=S.BLUE, edgecolor="white", lw=1.2, zorder=3)
    ax.scatter(s, i, s=34, color=S.ORANGE, edgecolor="white", lw=1.2, zorder=3)
    ax.text(r + 0.04, i, f"{r:.2f}", va="center", fontsize=6.3, color=S.INK)
    ax.text(s - 0.04, i, f"{s:.2f}", va="center", ha="right", fontsize=6.3, color=S.INK)
    ax.text((r + s) / 2, i + 0.3, b, ha="center", fontsize=5.7, color=S.MUTED)
ax.axvline(0, color=S.MUTED, lw=0.7, ls=(0, (2, 2)))
ax.text(-0.07, 3.5, "← worse than\npredicting the mean", fontsize=5.7,
        color=S.MUTED, va="center", ha="right")
ax.set_yticks(range(len(rows)))
ax.set_yticklabels([r[0] for r in rows[::-1]], fontsize=6.5, color=S.INK)
ax.set_xlim(-1.5, 0.9); ax.set_ylim(-0.6, len(rows) - 0.3)
ax.set_xlabel("Cross-validated R² (log concentration)")
ax.tick_params(axis="y", length=0)
ax.spines["left"].set_visible(False)
ax.grid(axis="x", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
ax.legend(handles=[Line2D([], [], marker="o", ls="", color=S.BLUE, ms=5, label="random CV"),
                   Line2D([], [], marker="o", ls="", color=S.ORANGE, ms=5,
                          label="held-out region")],
          loc="lower left", bbox_to_anchor=(0, 1.0), ncol=2, borderaxespad=0.1)
ax.set_title("Accuracy at unsampled locations is far lower", loc="left", color=S.INK, pad=16)
S.panel(ax, "a", x=-0.27, y=1.1)

# ---------------- (b) predictor leakage
ax = fig.add_subplot(gs[0, 1])
groups = [("Bangladesh As\n(100 km)", (bd_loc["random"], bd_loc["100 km"]),
           (cvm("Bangladesh (national) As", "chem+xy", "random"),
            cvm("Bangladesh (national) As", "chem+xy", "spatial", 100))),
          ("Pakistan F\n(new district)", (pkm("F", "location+depth", "random"), pkm("F", "location+depth", "district")),
           (pkm("F", "+co-measured chem", "random"), pkm("F", "+co-measured chem", "district"))),
          ("Pakistan NO₃\n(new district)", (pkm("NO3", "location+depth", "random"), pkm("NO3", "location+depth", "district")),
           (pkm("NO3", "+co-measured chem", "random"), pkm("NO3", "+co-measured chem", "district")))]
w = 0.19
for gi, (lab, loc, chem) in enumerate(groups):
    xs = gi + np.array([-1.5, -0.5, 0.5, 1.5]) * (w + 0.02)
    vals = [loc[0], loc[1], chem[0], chem[1]]
    cols = [S.BLUE, S.ORANGE, S.BLUE, S.ORANGE]
    hatch = ["", "", "////", "////"]
    for x, v, c, h in zip(xs, vals, cols, hatch):
        ax.bar(x, v, width=w, color=c, edgecolor="white" if not h else "white",
               hatch=h, lw=0.0, zorder=2)
        ax.text(x, v + (0.03 if v >= 0 else -0.03), f"{v:.2f}", ha="center",
                va="bottom" if v >= 0 else "top", fontsize=5.4, color=S.INK, rotation=90)
ax.axhline(0, color=S.MUTED, lw=0.7)
ax.set_xticks(range(len(groups))); ax.set_xticklabels([g[0] for g in groups], fontsize=6.3, color=S.INK)
ax.tick_params(axis="x", length=0)
ax.set_ylim(-1.45, 1.1); ax.set_ylabel("Cross-validated R²")
ax.grid(axis="y", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
plt.rcParams["hatch.color"] = "white"
ax.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=S.MUTED, label="mappable inputs only"),
                   plt.Rectangle((0, 0), 1, 1, facecolor=S.MUTED, hatch="////", edgecolor="white",
                                 label="+ co-measured chemistry")],
          loc="lower left", bbox_to_anchor=(0, 1.0), ncol=1, borderaxespad=0.1)
ax.set_title("Co-measured chemistry inflates skill", loc="left", color=S.INK, pad=26)
S.panel(ax, "b", x=-0.25, y=1.1)

# ---------------- (c) conformal coverage
ax = fig.add_subplot(gs[1, 0])
order = ["USA As", "Araihazar As", "Bangladesh national As", "USA F", "Pakistan NO3", "Pakistan F"]
names = {"USA As": "USA As", "Araihazar As": "Araihazar As",
         "Bangladesh national As": "Bangladesh As", "USA F": "USA F",
         "Pakistan NO3": "Pakistan NO₃", "Pakistan F": "Pakistan F"}
for i, ds in enumerate(order[::-1]):
    for sch, c, dy in [("random", S.BLUE, 0.14), ("spatial", S.ORANGE, -0.14)]:
        r = cf[(cf.dataset == ds) & (cf.scheme == sch)].iloc[0]
        ax.plot([r.coverage_min, r.coverage_max], [i + dy, i + dy], color=c, lw=1.4,
                alpha=0.45, solid_capstyle="round")
        ax.scatter(r.coverage_mean, i + dy, s=26, color=c, edgecolor="white", lw=1, zorder=3)
        if sch == "spatial":
            ax.text(r.coverage_min - 0.015, i + dy, f"{r.coverage_min:.0%}", ha="right",
                    va="center", fontsize=5.6, color=S.MUTED)
ax.axvline(0.9, color=S.INK, lw=0.8, ls=(0, (3, 2)))
ax.text(0.905, len(order) - 0.45, "nominal 90%", fontsize=6, color=S.INK)
ax.set_yticks(range(len(order))); ax.set_yticklabels([names[o] for o in order[::-1]], fontsize=6.5, color=S.INK)
ax.set_xlim(0.25, 1.0)
ax.set_xticks([0.3, 0.5, 0.7, 0.9]); ax.set_xticklabels(["30%", "50%", "70%", "90%"])
ax.set_xlabel("Share of wells inside the 90% prediction interval (mean, fold range)")
ax.tick_params(axis="y", length=0); ax.spines["left"].set_visible(False)
ax.grid(axis="x", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
ax.legend(handles=[Line2D([], [], marker="o", color=S.BLUE, ms=4.5, lw=1.2, label="random wells"),
                   Line2D([], [], marker="o", color=S.ORANGE, ms=4.5, lw=1.2, label="held-out region")],
          loc="lower left", bbox_to_anchor=(0, 1.0), ncol=2, borderaxespad=0.1)
ax.set_title("Uncertainty is understated in new regions", loc="left", color=S.INK, pad=16)
S.panel(ax, "c", x=-0.27, y=1.1)

# ---------------- (d) transfer to Türkiye
ax = fig.add_subplot(gs[1, 1])
home = tt.loc["Pakistan internal (random CV)"]
tr = tt.loc["Transfer to Türkiye both seasons"]
cats = ["Lower Indus\n(training region)", "Kazan Basin\n(new region)"]
obs = [home.observed_unsafe, tr.observed_unsafe]
flg = [home.flagged_unsafe, tr.flagged_unsafe]
x = np.arange(2)
ax.bar(x - 0.17, obs, width=0.3, color=S.MUTED, zorder=2, label="truly > 10 µg/L")
ax.bar(x + 0.17, flg, width=0.3, color=S.ORANGE, zorder=2, label="flagged by model")
for xi, o, f in zip(x, obs, flg):
    ax.text(xi - 0.17, o + 0.02, f"{o:.0%}", ha="center", fontsize=6.3, color=S.INK)
    ax.text(xi + 0.17, f + 0.02, f"{f:.0%}", ha="center", fontsize=6.3, color=S.INK)
ax.text(0, 0.16, f"AUC {home.auc:.2f}", ha="center", fontsize=6.6, color=S.INK, fontweight="bold")
ax.text(1, 0.97, f"AUC {tr.auc:.2f}\n(chance = 0.50)", ha="center", va="bottom",
        fontsize=6.6, color=S.INK, fontweight="bold")
ax.set_xticks(x); ax.set_xticklabels(cats, fontsize=6.5, color=S.INK)
ax.tick_params(axis="x", length=0)
ax.set_ylim(0, 1.18); ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
ax.set_yticklabels(["0%", "25%", "50%", "75%", "100%"])
ax.set_ylabel("Share of samples")
ax.grid(axis="y", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
ax.legend(loc="lower left", bbox_to_anchor=(0, 1.0), ncol=1, borderaxespad=0.1)
ax.set_title("Transfer to Türkiye fails", loc="left", color=S.INK, pad=26)
S.panel(ax, "d", x=-0.25, y=1.1)

fig.subplots_adjust(left=0.12, right=0.985, top=0.9, bottom=0.09)
for ext in ["png", "pdf", "tiff"]:
    fig.savefig(f"{OUT}/Fig2_results.{ext}",
                **({"pil_kwargs": {"compression": "tiff_lzw"}} if ext == "tiff" else {}))
print("ok")
