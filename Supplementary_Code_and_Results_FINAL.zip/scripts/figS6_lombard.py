"""Fig. S6: published USGS national arsenic model predictors, random vs leave-one-ecoregion-out."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import style as S

S.apply()
R = "/home/claude/data/results"
cv = pd.read_csv(f"{R}/lombard_cv.csv")
pe = pd.read_csv(f"{R}/lombard_per_ecoregion.csv")

fig = plt.figure(figsize=(S.DOUBLE, 3.6))
axes = [fig.add_axes([0.17, 0.13, 0.25, 0.64]), fig.add_axes([0.665, 0.13, 0.31, 0.64])]
ax = axes[0]
order = [("bas10", "XGBoost"), ("bas10", "Random forest"), ("bas5", "XGBoost"), ("bas5", "Random forest")]
labs = ["As > 10, XGBoost", "As > 10, random forest", "As > 5, XGBoost", "As > 5, random forest"]
for i, ((tg, md), lab) in enumerate(zip(order[::-1], labs[::-1])):
    sub = cv[(cv.target == tg) & (cv.model == md)]
    r = sub[sub.scheme == "random 5-fold"].auc.mean()
    s = sub[sub.scheme == "leave-one-ecoregion-out"].auc.mean()
    ax.plot([s, r], [i, i], color=S.RULE, lw=2, zorder=1)
    ax.scatter(r, i, s=30, color=S.BLUE, edgecolor="white", lw=0.8, zorder=3)
    ax.scatter(s, i, s=30, color=S.ORANGE, edgecolor="white", lw=0.8, zorder=3)
    ax.text(r + 0.025, i, f"{r:.2f}", va="center", fontsize=6)
    ax.text(s - 0.025, i, f"{s:.2f}", va="center", ha="right", fontsize=6)
ax.axvline(0.5, color=S.MUTED, lw=0.6, ls=":")
ax.set_yticks(range(4)); ax.set_yticklabels(labs[::-1], fontsize=6.2)
ax.set_xlim(0.45, 1.0); ax.set_xlabel("ROC-AUC")
ax.tick_params(axis="y", length=0); ax.spines["left"].set_visible(False)
ax.grid(axis="x", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
ax.legend(handles=[plt.Line2D([], [], marker="o", ls="", color=S.BLUE, ms=5, label="random 5-fold"),
                   plt.Line2D([], [], marker="o", ls="", color=S.ORANGE, ms=5, label="ecoregion held out")],
          loc="lower left", bbox_to_anchor=(0, 1.0), ncol=1, fontsize=6)
ax.set_title("All wells", loc="left", pad=30)
fig.text(0.015, 0.94, "a", fontsize=10, fontweight="bold")

ax = axes[1]
p = pe[pe.target == "bas10"].sort_values("auc_random")
y = np.arange(len(p))
ax.barh(y + 0.2, p.auc_random, height=0.38, color=S.BLUE, label="random 5-fold")
ax.barh(y - 0.2, p.auc_heldout, height=0.38, color=S.ORANGE, label="ecoregion held out")
ax.axvline(0.5, color=S.INK, lw=0.7, ls=":")
ax.set_yticks(y)
ax.set_yticklabels([f"{e} (n = {n:,})" for e, n in zip(p.ecoregion, p.n)], fontsize=5.6)
ax.set_xlim(0.3, 1.0); ax.set_xlabel("ROC-AUC within ecoregion")
ax.tick_params(axis="y", length=0); ax.spines["left"].set_visible(False)
ax.grid(axis="x", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
ax.legend(loc="lower left", bbox_to_anchor=(0, 1.0), ncol=1, fontsize=6)
ax.set_title("By ecoregion (As > 10, XGBoost)", loc="left", pad=30)
fig.text(0.415, 0.94, "b", fontsize=10, fontweight="bold")
for ext in ["png", "pdf"]:
    fig.savefig(f"/home/claude/data/figs/FigS6_usgs_model_predictors.{ext}")
print("ok")
