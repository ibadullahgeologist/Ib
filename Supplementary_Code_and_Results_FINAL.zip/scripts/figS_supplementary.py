"""Supplementary figures S1-S4."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shap
from sklearn.model_selection import GroupKFold
from xgboost import XGBRegressor
from scipy.stats import spearmanr
import style as S
import pakistan_cv as pc

S.apply()
R = "/home/claude/data/results"
OUT = "/home/claude/data/figs"


def save(fig, name):
    for ext in ["png", "pdf"]:
        fig.savefig(f"{OUT}/{name}.{ext}")


# ---------- S1: skill vs block size
cv = pd.concat([pd.read_csv(f"{R}/cv_BangladeshnationalAs_BangladeshAraihazarAs.csv"),
                pd.read_csv(f"{R}/cv_USAnationalAs_USAnationalF.csv")])
bl = pd.read_csv(f"{R}/cv_bangladesh_location_only.csv").assign(
    dataset="Bangladesh (national) As", features="location")
pk = pd.read_csv(f"{R}/cv_pakistan.csv")
fig, axes = plt.subplots(2, 3, figsize=(S.DOUBLE, 4.6))
panels = [("Bangladesh (national) As", "Bangladesh national As (log R²)"),
          ("Bangladesh (Araihazar) As", "Araihazar As (log R²)"),
          ("USA (national) As", "USA As (log R²)"),
          ("USA (national) F", "USA F (log R²)")]
lab = {"chem+xy": "with location", "chem": "without location", "location": "location + depth only"}
col = {"chem+xy": S.BLUE, "chem": S.MUTED, "location": S.ORANGE}
for ax, (ds, title), letter in zip(axes.flat[:4], panels, "abcd"):
    d = pd.concat([cv[cv.dataset == ds], bl[bl.dataset == ds]])
    for fs in d.features.unique():
        g = d[d.features == fs].groupby("block_km").r2.agg(["mean", "std"]).reset_index()
        xs = np.arange(len(g))
        ax.errorbar(xs, g["mean"], yerr=g["std"], color=col[fs], marker="o", ms=3.5,
                    lw=1.5, capsize=0, label=lab[fs])
        ax.set_xticks(xs)
        ax.set_xticklabels(["random"] + [f"{b:g}" for b in g.block_km[1:]], fontsize=6)
    ax.set_title(title, loc="left", color=S.INK, fontsize=7.5)
    ax.set_xlabel("Block size (km)", fontsize=6.5)
    ax.grid(axis="y", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
    ax.legend(fontsize=5.8, loc="lower left")
    S.panel(ax, letter, x=-0.2)
for ax, (tg, title, ylab), letter in zip(axes.flat[4:], [
        ("As>10", "Pakistan As > 10 µg/L", "ROC-AUC"),
        ("F", "Pakistan F and NO₃", "log R²")], "ef"):
    targets = [tg] if tg == "As>10" else ["F", "NO3"]
    for t in targets:
        for fs, ls in [("location+depth", "-"), ("+co-measured chem", "--")]:
            d = pk[(pk.target == t) & (pk.features == fs)]
            g = d.groupby("cv", sort=False).score.mean()
            c = S.ORANGE if t != "NO3" else S.VIOLET
            ax.plot(range(len(g)), g.values, ls=ls, marker="o", ms=3.5, lw=1.4, color=c,
                    label=f"{t.replace('As>10', 'As').replace('NO3', 'NO₃')}, {fs.replace('+co-measured chem', '+ chemistry')}")
            ax.set_xticks(range(len(g)))
            ax.set_xticklabels(["random", "10", "25", "50", "district"], fontsize=6)
    if tg == "As>10":
        ax.axhline(0.5, color=S.MUTED, lw=0.7, ls=":")
    else:
        ax.axhline(0, color=S.MUTED, lw=0.7, ls=":")
    ax.set_ylabel(ylab, fontsize=6.5); ax.set_xlabel("Block size (km) / leave-one-district-out", fontsize=6.5)
    ax.set_title(title, loc="left", color=S.INK, fontsize=7.5)
    ax.grid(axis="y", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
    ax.legend(fontsize=5.5, loc="lower left")
    S.panel(ax, letter, x=-0.2)
fig.tight_layout(h_pad=1.6, w_pad=1.2)
save(fig, "FigS1_block_size")

# ---------- S2: SHAP ranking per held-out district group (Pakistan F)
p = pc.p
cols = ["x_km", "y_km", "depth"] + pc.CHEM
nice = {c: c.split(" (")[0].replace("x_km", "Easting").replace("y_km", "Northing")
        .replace("depth", "Depth") for c in cols}
X = p[cols].astype(float); y = np.log10(p["F (mg/l)"].values + 0.01)
idx = np.random.default_rng(42).choice(len(X), min(len(X), 3000), replace=False)
imps, foldnames = [], []
for k, (tr, te) in enumerate(GroupKFold(5).split(X, y, p.District)):
    m = XGBRegressor(n_estimators=300, max_depth=5, learning_rate=0.05, subsample=0.8,
                     colsample_bytree=0.8, random_state=0).fit(X.iloc[tr], y[tr])
    imps.append(np.abs(shap.TreeExplainer(m).shap_values(X.iloc[idx])).mean(0))
    foldnames.append("w/o " + ", ".join(sorted(p.District.iloc[te].unique()))[:38])
imps = np.array(imps)
ranks = (-imps).argsort(1).argsort(1) + 1
order = np.argsort(ranks.mean(0))
pd.DataFrame(imps, columns=[nice[c] for c in cols], index=foldnames).to_csv(
    f"{R}/shap_pakistan_F_by_district_fold.csv")
fig, ax = plt.subplots(figsize=(S.DOUBLE, 3.2))
im = ax.imshow(ranks[:, order].T, cmap="Blues_r", aspect="auto", vmin=1, vmax=len(cols))
for i in range(ranks.shape[0]):
    for j, o in enumerate(order):
        r = ranks[i, o]
        ax.text(i, j, r, ha="center", va="center", fontsize=6,
                color="white" if r <= 5 else S.INK)
ax.set_yticks(range(len(cols))); ax.set_yticklabels([nice[cols[o]] for o in order], fontsize=6.5)
ax.set_xticks(range(len(foldnames)))
ax.set_xticklabels([f"Model {i+1}\n(5 districts\nheld out)" if False else f"Model {i+1}" for i in range(len(foldnames))], fontsize=6.5)
ax.set_title("Pakistan fluoride: SHAP importance rank (1 = most important) when different districts are held out",
             loc="left", color=S.INK, fontsize=7.5)
for s in ax.spines.values():
    s.set_visible(False)
cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.01); cb.set_label("rank", fontsize=6.5)
cb.ax.invert_yaxis()
fig.tight_layout()
save(fig, "FigS2_shap_rank_instability")
rho = [spearmanr(imps[i], imps[j])[0] for i in range(5) for j in range(i + 1, 5)]
print("S2 mean rho across district folds:", round(np.mean(rho), 2), "folds:", foldnames)

# ---------- S3: censoring
cs = pd.read_csv(f"{R}/censoring_sensitivity.csv")
rl = pd.read_csv(f"{R}/usa_as_reporting_limits.csv").sort_values("reporting_limit_ugL")
fig, axes = plt.subplots(1, 2, figsize=(S.DOUBLE, 2.5), gridspec_kw={"width_ratios": [1.2, 1]})
ax = axes[0]
top = rl[rl.n_wells >= 100]
ax.bar(range(len(top)), top.n_wells, color=S.BLUE, width=0.7)
ax.set_xticks(range(len(top))); ax.set_xticklabels([f"{v:g}" for v in top.reporting_limit_ugL], fontsize=6)
ax.set_xlabel("Reporting limit of non-detect (µg/L)"); ax.set_ylabel("Wells")
ax.set_title("USA As: non-detect reporting limits range up to 10 µg/L", loc="left", color=S.INK, fontsize=7.5)
ax.grid(axis="y", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
S.panel(ax, "a", x=-0.18)
ax = axes[1]
rules = ["DL", "DL/2", "zero"]
for k, (sch, c) in enumerate([("random", S.BLUE), ("spatial", S.ORANGE)]):
    v = [cs[(cs.rule == r) & (cs.scheme == sch)].r2.iloc[0] for r in rules]
    xs = np.arange(3) + (k - 0.5) * 0.36
    ax.bar(xs, v, width=0.34, color=c, label=f"{sch} CV" if sch == "random" else "spatial CV (400 km)")
    for x, vv in zip(xs, v):
        ax.text(x, vv + 0.01, f"{vv:.2f}", ha="center", fontsize=6)
ax.set_xticks(range(3)); ax.set_xticklabels(["non-detect = DL", "= DL/2", "= 0"], fontsize=6.5)
ax.set_ylabel("Cross-validated R²"); ax.set_ylim(0, 0.6)
ax.set_title("Substitution rule changes reported skill", loc="left", color=S.INK, fontsize=7.5)
ax.legend(fontsize=6, loc="upper right")
ax.grid(axis="y", color=S.GRID, lw=0.6); ax.set_axisbelow(True)
S.panel(ax, "b", x=-0.18)
fig.tight_layout()
save(fig, "FigS3_censoring")

# ---------- S4: Turkey seasonal pairs + small-data instability
sp = pd.read_csv(f"{R}/turkey_seasonal_pairs.csv")
sd = pd.read_csv(f"{R}/turkey_smalldata.csv")
fig, axes = plt.subplots(1, 2, figsize=(S.DOUBLE, 2.7))
ax = axes[0]
ax.plot([1, 3000], [1, 3000], color=S.RULE, lw=0.8)
ax.axvline(10, color=S.MUTED, lw=0.6, ls=":"); ax.axhline(10, color=S.MUTED, lw=0.6, ls=":")
sw = (sp.Dry_As_ug_L > 10) != (sp.Wet_As_ug_L > 10)
ax.scatter(sp.Dry_As_ug_L[~sw], sp.Wet_As_ug_L[~sw], s=22, color=S.BLUE, edgecolor="white", lw=0.6,
           label="same class in both seasons")
ax.scatter(sp.Dry_As_ug_L[sw], sp.Wet_As_ug_L[sw], s=30, color=S.ORANGE, edgecolor="white", lw=0.6,
           label="switches across 10 µg/L")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(2, 3000); ax.set_ylim(2, 3000)
ax.set_xlabel("Dry season As, Oct 2021 (µg/L)"); ax.set_ylabel("Wet season As, Apr 2022 (µg/L)")
ax.set_title(f"Kazan Basin: {len(sp)} re-sampled sites", loc="left", color=S.INK, fontsize=7.5)
ax.legend(fontsize=6, loc="upper left")
S.panel(ax, "a", x=-0.2)
ax = axes[1]
ax.hist(sd.r2, bins=12, color=S.ORANGE, edgecolor="white")
ax.axvline(0, color=S.INK, lw=0.8, ls="--")
ax.text(0.01, ax.get_ylim()[1] * 0.92, "mean predictor", fontsize=6, color=S.INK)
ax.set_xlabel("Cross-validated R² (30 repeats of 5-fold CV)"); ax.set_ylabel("Repeats")
ax.set_title("Kazan Basin alone (n = 33): no stable skill", loc="left", color=S.INK, fontsize=7.5)
S.panel(ax, "b", x=-0.2)
fig.tight_layout()
save(fig, "FigS4_turkey_seasonal_smalldata")
print("ok")
