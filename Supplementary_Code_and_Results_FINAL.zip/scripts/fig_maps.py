"""Global prediction and uncertainty maps (USA As, Bangladesh As, Pakistan F).

For each region: observed values; out-of-fold predictions under random CV; under spatial
CV; and 90% conformalized-quantile-regression (CQR) interval width under spatial CV.
Also writes CQR coverage (random vs spatial) and SHAP dependence directions for Pakistan F.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from mpl_toolkits.basemap import Basemap
from pyproj import Transformer
from sklearn.model_selection import KFold, GroupKFold
from xgboost import XGBRegressor
import shap
import style as S
import load_data as ld
import pakistan_cv as pc

S.apply()
RES, OUT = "/home/claude/data/results", "/home/claude/data/figs"
CONC = LinearSegmentedColormap.from_list("conc", ["#f3f2ee", "#f6b48f", "#eb6834", "#a53d14", "#4a1a08"])
UNC = LinearSegmentedColormap.from_list("unc", ["#eef4fc", "#9ec5f4", "#3987e5", "#184f95", "#0d2a52"])


def xgb(obj="reg:squarederror", alpha=None, seed=0):
    kw = dict(n_estimators=400, max_depth=6, learning_rate=0.05, subsample=0.8,
              colsample_bytree=0.8, n_jobs=-1, random_state=seed, tree_method="hist")
    if alpha is not None:
        kw.update(objective="reg:quantileerror", quantile_alpha=alpha)
    return XGBRegressor(**kw)


def blocks(df, b, seed=0):
    g = (np.floor(df.x_km / b).astype(int).astype(str) + "_" +
         np.floor(df.y_km / b).astype(int).astype(str)).values
    ug = np.unique(g)
    fo = dict(zip(ug, np.random.default_rng(seed).integers(0, 5, len(ug))))
    return np.array([fo[v] for v in g])


def oof(X, y, splits, cqr=False, alpha=0.1):
    pred = np.zeros(len(y)); lo = np.zeros(len(y)); hi = np.zeros(len(y))
    for tr, te in splits:
        pred[te] = xgb().fit(X.iloc[tr], y[tr]).predict(X.iloc[te])
        if cqr:
            r = np.random.default_rng(0).permutation(tr)
            cal, fit = r[: len(r) // 4], r[len(r) // 4:]
            ql = xgb(alpha=alpha / 2).fit(X.iloc[fit], y[fit])
            qh = xgb(alpha=1 - alpha / 2).fit(X.iloc[fit], y[fit])
            e = np.maximum(ql.predict(X.iloc[cal]) - y[cal], y[cal] - qh.predict(X.iloc[cal]))
            q = np.quantile(e, min(1, np.ceil((len(cal) + 1) * (1 - alpha)) / len(cal)), method="higher")
            lo[te] = ql.predict(X.iloc[te]) - q
            hi[te] = qh.predict(X.iloc[te]) + q
    return pred, lo, hi


regions = []
# USA arsenic
df, feats = ld.usa_arsenic(); df = df.reset_index(drop=True)
lon, lat = Transformer.from_crs("EPSG:5070", "EPSG:4326", always_xy=True).transform(
    df.XCoord.values, df.YCoord.values)
regions.append(dict(name="USA arsenic", unit="log₁₀(As + 1), µg/L", df=df, lon=lon, lat=lat,
                    cols=feats + ["x_km", "y_km"], y=np.log10(df.target.clip(lower=0).values + 1),
                    groups=blocks(df, 400), gname="400 km blocks",
                    box=(-125, -66.5, 24.5, 49.5), proj="merc", res="l"))
# Bangladesh arsenic (mappable predictors)
df, _ = ld.bangladesh_national(); df = df.reset_index(drop=True)
regions.append(dict(name="Bangladesh arsenic", unit="log₁₀(As + 1), µg/L", df=df,
                    lon=df.lon.values, lat=df.lat.values, cols=["depth", "x_km", "y_km"],
                    y=np.log10(df.target.clip(lower=0).values + 1), groups=blocks(df, 100),
                    gname="100 km blocks", box=(88.0, 92.7, 20.6, 26.7), proj="merc", res="i"))
# Pakistan fluoride (mappable predictors)
p = pc.p.reset_index(drop=True)
regions.append(dict(name="Lower Indus fluoride", unit="log₁₀(F + 0.01), mg/L", df=p,
                    lon=p.Longitude.values, lat=p.Latitude.values, cols=["x_km", "y_km", "depth"],
                    y=np.log10(p["F (mg/l)"].values + 0.01), groups=p.District.values,
                    gname="held-out districts", box=(66.9, 71.3, 23.8, 28.7), proj="merc", res="i"))

import os, pickle
CACHE = f"{RES}/maps_cache.pkl"
if os.path.exists(CACHE):
    cached = pickle.load(open(CACHE, "rb"))
    for R in regions:
        R.update(cached[R["name"]])
cov_rows = []
for R in regions:
    if "p_rand" in R:
        continue
    X = R["df"][R["cols"]].astype(float)
    y = R["y"]
    rnd = list(KFold(5, shuffle=True, random_state=0).split(X))
    ug = np.random.default_rng(0).permutation(np.unique(R["groups"]))
    fo = {g: i % 5 for i, g in enumerate(ug)}
    spa = list(GroupKFold(5).split(X, y, np.array([fo[g] for g in R["groups"]])))
    R["p_rand"], lo_r, hi_r = oof(X, y, rnd, cqr=True)
    R["p_spat"], lo_s, hi_s = oof(X, y, spa, cqr=True)
    R["width"] = hi_s - lo_s
    for sch, lo, hi in [("random", lo_r, hi_r), ("spatial", lo_s, hi_s)]:
        cov_rows.append(dict(region=R["name"], scheme=sch, coverage=np.mean((y >= lo) & (y <= hi)),
                             mean_width=np.mean(hi - lo)))
    print(R["name"], "done", flush=True)
if cov_rows:
    pd.DataFrame(cov_rows).to_csv(f"{RES}/cqr_coverage.csv", index=False)
pickle.dump({R["name"]: {k: R[k] for k in ["p_rand", "p_spat", "width"]} for R in regions}, open(CACHE, "wb"))
print(pd.DataFrame(cov_rows).round(3).to_string()) if cov_rows else None

# ---------- figure
fig, axes5 = plt.subplots(3, 5, figsize=(S.DOUBLE, 5.9),
                          gridspec_kw={"height_ratios": [0.5, 1, 1], "width_ratios": [1, 1, 1, 1, 0.34],
                                       "hspace": 0.12, "wspace": 0.05})
axes = axes5[:, :4]
for a_ in axes5[:, 4]:
    a_.axis("off")
heads = ["Observed", "Predicted (random CV)", "Predicted (spatial CV)", "90% interval width\n(spatial CV)"]
for r, R in enumerate(regions):
    vmin, vmax = np.percentile(R["y"], [2, 98])
    wmin, wmax = np.percentile(R["width"], [2, 98])
    order = np.argsort(R["y"])
    for c in range(4):
        ax = axes[r, c]
        lo0, lo1, la0, la1 = R["box"]
        m = Basemap(projection=R["proj"], llcrnrlon=lo0, urcrnrlon=lo1, llcrnrlat=la0, urcrnrlat=la1,
                    resolution=R["res"], ax=ax)
        m.drawmapboundary(fill_color="white", color=S.RULE, linewidth=0.4)
        m.fillcontinents(color="#f1f0ec", lake_color="white", zorder=0)
        m.drawcountries(color=S.RULE, linewidth=0.4)
        m.drawcoastlines(color=S.RULE, linewidth=0.3)
        if r == 0:
            m.drawstates(color="#e2e1dc", linewidth=0.2)
        x, yy = m(R["lon"][order], R["lat"][order])
        val = [R["y"], R["p_rand"], R["p_spat"], R["width"]][c][order]
        sz = 0.6 if r == 0 else (1.6 if r == 1 else 3.5)
        sc = ax.scatter(x, yy, c=val, s=sz, lw=0, cmap=UNC if c == 3 else CONC,
                        vmin=wmin if c == 3 else vmin, vmax=wmax if c == 3 else vmax,
                        rasterized=True, zorder=3)
        if r == 0:
            ax.set_title(heads[c], fontsize=7.2, color=S.INK, pad=4)
        if c == 0:
            S.panel(ax, "abc"[r], x=-0.16, y=0.97)
            ax.text(-0.04, 0.5, R["name"], transform=ax.transAxes, rotation=90, ha="right",
                    va="center", fontsize=7.2, color=S.INK, fontweight="bold")
        if c in (2, 3):
            ax.text(0.98, 0.02, R["gname"], transform=ax.transAxes, ha="right", va="bottom",
                    fontsize=5.4, color=S.MUTED,
                    bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.8))
        if c == 2:
            cb_conc = sc
        if c == 3:
            cb_unc = sc
    # colorbars per row, in the dedicated fifth column
    cax_host = axes5[r, 4]
    c1 = cax_host.inset_axes([0.08, 0.62, 0.16, 0.27])
    cb = fig.colorbar(cb_conc, cax=c1); cb.ax.tick_params(labelsize=5.2, length=1.5)
    cb.ax.set_title(R["unit"].split(",")[0], fontsize=5.4, color=S.INK, pad=3, loc="left")
    c2 = cax_host.inset_axes([0.08, 0.06, 0.16, 0.27])
    cb = fig.colorbar(cb_unc, cax=c2); cb.ax.tick_params(labelsize=5.2, length=1.5)
    cb.ax.set_title("width", fontsize=5.4, color=S.INK, pad=3, loc="left")
fig.subplots_adjust(left=0.05, right=0.985, top=0.95, bottom=0.01)
for ext in ["png", "pdf", "tiff"]:
    fig.savefig(f"{OUT}/Fig3_global_maps.{ext}",
                **({"pil_kwargs": {"compression": "tiff_lzw"}} if ext == "tiff" else {}))

# ---------- SHAP dependence directions, Pakistan F with chemistry (for interpretation)
cols = ["x_km", "y_km", "depth"] + pc.CHEM
X = p[cols].astype(float); y = np.log10(p["F (mg/l)"].values + 0.01)
mdl = xgb().fit(X, y)
sv = shap.TreeExplainer(mdl).shap_values(X)
rows = []
for i, c in enumerate(cols):
    rows.append(dict(feature=c, mean_abs_shap=np.abs(sv[:, i]).mean(),
                     spearman_value_vs_shap=pd.Series(X[c]).corr(pd.Series(sv[:, i]), method="spearman")))
pd.DataFrame(rows).sort_values("mean_abs_shap", ascending=False).to_csv(
    f"{RES}/shap_direction_pakistan_F.csv", index=False)
print(pd.DataFrame(rows).sort_values("mean_abs_shap", ascending=False).round(3).to_string())
print("ok")
