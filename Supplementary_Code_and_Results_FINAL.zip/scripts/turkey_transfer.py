"""Transfer test: chemistry-only arsenic model trained on Pakistan (Lower Indus),
applied to Kazan Basin (Türkiye). Also the Turkey-only small-data test and
seasonal-pair statistics. Writes results/turkey_*.csv."""
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, r2_score
from sklearn.model_selection import StratifiedKFold, KFold, cross_val_predict
from xgboost import XGBClassifier, XGBRegressor

RES = "/home/claude/data/results"
p = pd.read_excel("/home/claude/data/pakistan/pak.xlsx")
t = pd.read_excel("/home/claude/data/turkey/tur.xlsx", "Analysis_Ready")
PM = {"EC": "EC (uS/cm)", "pH": "pH", "HCO3": "HCO3 (mg/l)", "Cl": "Cl (mg/l)",
      "SO4": "SO4 (mg/l)", "Ca": "Ca (mg/l)", "Mg": "Mg (mg/l)", "Na": "Na (mg/l)",
      "K": "K (mg/l)", "NO3": "NO3 (mg/l)", "Fe": "Fe (mg/l)"}
TM = {"EC": "EC_uS_cm", "pH": "pH", "HCO3": "HCO3_mg_L", "Cl": "Cl_mg_L",
      "SO4": "SO4_mg_L", "Ca": "Ca_mg_L", "Mg": "Mg_mg_L", "Na": "Na_mg_L",
      "K": "K_mg_L", "NO3": "NO3_mg_L", "Fe": "Fe_ug_L"}
Xp = pd.DataFrame({k: p[v] for k, v in PM.items()}).astype(float)
yp = (p["As µg"] > 10).astype(int).values
t = t[t.Thermal_Flag == "No"].reset_index(drop=True)  # drop thermal end-member
Xt = pd.DataFrame({k: t[v] for k, v in TM.items()}).astype(float)
Xt["Fe"] = Xt["Fe"] / 1000  # ug/L -> mg/L
yt = (t.As_ug_L > 10).astype(int).values


def clf(s):
    return XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.05,
                         subsample=0.8, colsample_bytree=0.8, random_state=s)


rows = []
for s in range(5):
    pr = cross_val_predict(clf(s), Xp, yp, method="predict_proba",
                           cv=StratifiedKFold(5, shuffle=True, random_state=s))[:, 1]
    rows.append(dict(test="Pakistan internal (random CV)", seed=s, n=len(yp),
                     auc=roc_auc_score(yp, pr), observed_unsafe=yp.mean(),
                     flagged_unsafe=(pr > 0.5).mean(),
                     caught=((pr > 0.5) & (yp == 1)).sum() / yp.sum()))
    m = clf(s).fit(Xp, yp)
    for sub, mask in [("Türkiye dry season", t.Season == "Dry"),
                      ("Türkiye both seasons", t.Season.notna())]:
        mk = mask.values
        pr = m.predict_proba(Xt[mk])[:, 1]
        yy = yt[mk]
        rows.append(dict(test=f"Transfer to {sub}", seed=s, n=int(mk.sum()),
                         auc=roc_auc_score(yy, pr), observed_unsafe=yy.mean(),
                         flagged_unsafe=(pr > 0.5).mean(),
                         caught=((pr > 0.5) & (yy == 1)).sum() / yy.sum()))
res = pd.DataFrame(rows)
res.to_csv(f"{RES}/turkey_transfer.csv", index=False)
print(res.groupby("test", sort=False).mean(numeric_only=True).round(3).to_string())

# Turkey-only small-data test (dry season)
d = (t.Season == "Dry").values
X, y = Xt[d], np.log10(t.As_ug_L[d].values + 1)
r2 = []
for s in range(30):
    pr = np.zeros(len(y))
    for tr, te in KFold(5, shuffle=True, random_state=s).split(X):
        pr[te] = XGBRegressor(n_estimators=200, max_depth=3, learning_rate=0.05,
                              random_state=s).fit(X.iloc[tr], y[tr]).predict(X.iloc[te])
    r2.append(r2_score(y, pr))
pd.DataFrame({"repeat": range(30), "r2": r2}).to_csv(f"{RES}/turkey_smalldata.csv", index=False)
print(f"Turkey dry-only n={len(y)}: R2 mean {np.mean(r2):.2f}, range {min(r2):.2f}..{max(r2):.2f}")

sp = pd.read_excel("/home/claude/data/turkey/tur.xlsx", "Seasonal_Pairs")
sp.to_csv(f"{RES}/turkey_seasonal_pairs.csv", index=False)
sw = ((sp.Dry_As_ug_L > 10) != (sp.Wet_As_ug_L > 10)).sum()
print(f"pairs={len(sp)} median|d|={sp.Wet_minus_Dry_As.abs().median()} "
      f"max|d|={sp.Wet_minus_Dry_As.abs().max()} class switches={sw}")
