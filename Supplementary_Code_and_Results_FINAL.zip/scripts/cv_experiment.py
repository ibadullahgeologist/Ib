"""Random vs spatial-block cross-validation for groundwater contaminant models.

For each dataset and block size, an XGBoost regressor predicts log10 concentration.
Two feature sets are tested:
  'chem+xy'  hydrochemistry/depth + coordinates (common in the literature)
  'chem'     hydrochemistry/depth only
Metrics: R2 on log scale, and ROC-AUC for exceeding the WHO guideline
(As 10 ug/L, F 1.5 mg/L).
"""
import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold, GroupKFold
from sklearn.metrics import r2_score, roc_auc_score
from xgboost import XGBRegressor
from load_data import LOADERS

GUIDE = {"As": 10.0, "F": 1.5}
# spatial block edge lengths (km) tested per dataset
BLOCKS = {
    "Bangladesh (national) As": [10, 25, 50, 100],
    "Bangladesh (Araihazar) As": [0.25, 0.5, 1, 2],
    "USA (national) As": [25, 50, 100, 200, 400],
    "USA (national) F": [25, 50, 100, 200, 400],
}
SEEDS = [0, 1, 2]
K = 5


def model(seed):
    return XGBRegressor(n_estimators=400, max_depth=6, learning_rate=0.05,
                        subsample=0.8, colsample_bytree=0.8, n_jobs=-1,
                        random_state=seed, tree_method="hist")


def run_cv(X, y, guide, splitter, groups=None, seed=0):
    pred = np.zeros(len(y))
    for tr, te in splitter.split(X, y, groups):
        m = model(seed).fit(X.iloc[tr], y[tr])
        pred[te] = m.predict(X.iloc[te])
    exceed = (y > np.log10(guide)).astype(int)
    auc = roc_auc_score(exceed, pred) if 0 < exceed.mean() < 1 else np.nan
    return r2_score(y, pred), auc


def main(names):
    rows = []
    for name in names:
        df, feats = LOADERS[name]()
        sp = name.split()[-1]
        y = np.log10(df["target"].clip(lower=0).values +
                     (1.0 if sp == "As" else 0.01))
        guide = GUIDE[sp] + (1.0 if sp == "As" else 0.01)
        for fs in ["chem+xy", "chem"]:
            cols = feats + (["x_km", "y_km"] if fs == "chem+xy" else [])
            X = df[cols].astype(float)
            for s in SEEDS:
                r2, auc = run_cv(X, y, guide,
                                 KFold(K, shuffle=True, random_state=s), seed=s)
                rows.append(dict(dataset=name, features=fs, cv="random",
                                 block_km=0, seed=s, r2=r2, auc=auc))
                print(name, fs, "random", s, round(r2, 3), round(auc, 3),
                      flush=True)
                for b in BLOCKS[name]:
                    g = (np.floor(df.x_km / b).astype(int).astype(str) + "_" +
                         np.floor(df.y_km / b).astype(int).astype(str)).values
                    # shuffle block-to-fold assignment by seed
                    ug = np.unique(g)
                    rng = np.random.default_rng(s)
                    fold_of = dict(zip(ug, rng.integers(0, K, len(ug))))
                    folds = np.array([fold_of[v] for v in g])
                    r2, auc = run_cv(X, y, guide, GroupKFold(K),
                                     groups=folds, seed=s)
                    rows.append(dict(dataset=name, features=fs, cv="spatial",
                                     block_km=b, seed=s, r2=r2, auc=auc))
                    print(name, fs, f"block {b}", s, round(r2, 3),
                          round(auc, 3), flush=True)
    out = pd.DataFrame(rows)
    tag = "_".join("".join(ch for ch in n if ch.isalnum()) for n in names)
    out.to_csv(f"/home/claude/data/results/cv_{tag}.csv", index=False)
    return out


if __name__ == "__main__":
    names = sys.argv[1:] or list(LOADERS)
    main(names)
