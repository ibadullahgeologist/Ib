"""Figure 4 (redesign): next-generation explainable groundwater AI — wheel + evidence cards."""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Wedge, Circle, Polygon, Rectangle, ConnectionPatch
import style as S

S.apply()
import matplotlib as mpl
mpl.rcParams.update({"font.family": "serif",
                     "font.serif": ["Times New Roman", "Liberation Serif", "Times", "STIXGeneral"],
                     "mathtext.fontset": "stix"})
OUT = "/home/claude/data/figs"
COL = ["#2a78d6", "#1baf7a", "#c98500", "#d55181", "#6250d6"]  # stage colors (palette order)
TINT = ["#e8f1fc", "#e3f6ee", "#fbf1dc", "#fbe8ef", "#ecebfb"]

stages = [
    dict(title="Data", today="One campaign; non-detects\nsubstituted silently",
         nxt="Report detection limits, model\ncensoring, repeat seasons",
         big="23–43%", cap="of values below detection;\n2 of 21 sites switch class by season"),
    dict(title="Predictors", today="Co-measured chemistry and\nraw coordinates as inputs",
         nxt="Only inputs known at unsampled\nsites: geology, terrain, depth",
         big="0.81 vs 0.55", cap="R² with vs without same-well\nchemistry (Bangladesh As)"),
    dict(title="Validation", today="Random k-fold\ncross-validation",
         nxt="Spatial blocks, leave-region-out,\nan external basin, 2+ algorithms",
         big="−71%", cap="R² lost in new regions (USA As); AUC\n0.87 → 0.66 with USGS-model predictors"),
    dict(title="Explanation", today="One SHAP ranking read\nas the process drivers",
         nxt="Stable rankings across regions,\nchecked against geochemistry",
         big="ρ = 0.28", cap="SHAP rank agreement between\ndistricts (0.75 for random folds)"),
    dict(title="Uncertainty", today="One best-guess map;\nsuccesses only",
         nxt="Region-calibrated intervals,\narea of applicability, failures",
         big="7%", cap="of wells inside 90% intervals in\nTharparkar, the worst-affected district"),
]

fig = plt.figure(figsize=(S.DOUBLE, 6.3))
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(0, 88); ax.axis("off")


# ------------------------------------------------------------------ icons (white, in header)
def icon(i, cx, cy, s=1.6, c="white", z=6):
    if i == 0:  # droplet with dots (samples)
        ax.add_patch(Circle((cx, cy - 0.35 * s), 0.85 * s, fc=c, ec="none", zorder=z))
        ax.add_patch(Polygon([[cx - 0.75 * s, cy - 0.05 * s], [cx + 0.75 * s, cy - 0.05 * s], [cx, cy + 1.25 * s]], fc=c, ec="none", zorder=z))
        for dx, dy in [(-0.3, -0.5), (0.25, -0.25), (0.05, -0.8)]:
            ax.add_patch(Circle((cx + dx * s, cy + dy * s), 0.13 * s, fc=COL[0], ec="none", zorder=z + 1))
    elif i == 1:  # strata layers
        for k, w in enumerate([2.2, 1.8, 2.4]):
            ax.add_patch(FancyBboxPatch((cx - w / 2 * s, cy - 0.95 * s + k * 0.7 * s), w * s, 0.42 * s,
                                        boxstyle="round,pad=0,rounding_size=0.15", fc=c, ec="none", zorder=z))
    elif i == 2:  # 3x3 block grid, one held out
        for a in range(3):
            for b in range(3):
                held = (a, b) == (2, 0)
                ax.add_patch(Rectangle((cx - 1.05 * s + a * 0.72 * s, cy - 1.05 * s + b * 0.72 * s), 0.6 * s, 0.6 * s,
                                       fc=("none" if held else c), ec=c, lw=0.8, zorder=z))
    elif i == 3:  # importance bars
        for k, w in enumerate([2.1, 1.5, 0.9]):
            ax.add_patch(Rectangle((cx - 1.05 * s, cy + 0.55 * s - k * 0.62 * s), w * s, 0.4 * s, fc=c, ec="none", zorder=z))
    elif i == 4:  # prediction with interval
        xs = np.linspace(-1.1, 1.1, 30)
        ax.fill_between(cx + xs * s, cy + (0.25 * np.sin(xs * 2) - 0.55) * s, cy + (0.25 * np.sin(xs * 2) + 0.55) * s,
                        color=c, alpha=0.45, lw=0, zorder=z)
        ax.plot(cx + xs * s, cy + 0.25 * np.sin(xs * 2) * s, color=c, lw=1.2, zorder=z)


# ------------------------------------------------------------------ cards
W, H = 31.5, 32.5
pos = [(1.0, 47.5), (67.5, 47.5), (67.5, 9.5), (34.25, 1.0), (1.0, 9.5)]
for i, (st, (x, y)) in enumerate(zip(stages, pos)):
    c = COL[i]
    ax.add_patch(FancyBboxPatch((x, y), W, H, boxstyle="round,pad=0,rounding_size=1.6",
                                fc="white", ec=c, lw=1.0, zorder=2))
    # header
    ax.add_patch(FancyBboxPatch((x, y + H - 5.6), W, 5.6, boxstyle="round,pad=0,rounding_size=1.6",
                                fc=c, ec="none", zorder=3))
    ax.add_patch(Rectangle((x, y + H - 5.6), W, 2.0, fc=c, ec="none", zorder=3))
    ax.text(x + 2.0, y + H - 2.8, f"{i + 1}", color="white", fontsize=10, fontweight="bold", va="center", zorder=4)
    ax.text(x + 5.2, y + H - 2.8, st["title"], color="white", fontsize=9.5, fontweight="bold", va="center", zorder=4)
    icon(i, x + W - 3.6, y + H - 2.8)
    # today / next
    ty = y + H - 7.6
    ax.text(x + 2.0, ty, "TODAY", fontsize=6.0, color=S.MUTED, fontweight="bold", va="top")
    ax.text(x + 9.5, ty, st["today"], fontsize=6.8, color=S.MUTED, va="top", linespacing=1.2)
    ny = ty - 5.4
    ax.text(x + 2.0, ny, "NEXT", fontsize=6.0, color=c, fontweight="bold", va="top")
    ax.text(x + 9.5, ny, st["nxt"], fontsize=6.8, color=S.INK, va="top", linespacing=1.2)
    # evidence band
    ax.add_patch(FancyBboxPatch((x + 1.2, y + 1.2), W - 2.4, 13.2, boxstyle="round,pad=0,rounding_size=1.0",
                                fc=TINT[i], ec="none", zorder=2.5))
    ax.text(x + 2.4, y + 12.6, "EVIDENCE FROM THIS STUDY", fontsize=5.5, color=c, fontweight="bold", va="center", zorder=4)
    ax.text(x + 2.4, y + 8.7, st["big"], fontsize=14.5, color=c, fontweight="bold", va="center", zorder=4)
    ax.text(x + 2.4, y + 3.7, st["cap"], fontsize=6.2, color=S.INK, va="center", linespacing=1.15, zorder=4)

# ------------------------------------------------------------------ wheel
cx, cy, R, w = 50.0, 55.0, 13.0, 5.2
centers = [126, 54, -18, -90, -162]
for i, a in enumerate(centers):
    ax.add_patch(Wedge((cx, cy), R, a - 35, a + 35, width=w, fc=COL[i], ec="white", lw=1.5, zorder=3))
    rr = R - w / 2
    ax.text(cx + rr * np.cos(np.deg2rad(a)), cy + rr * np.sin(np.deg2rad(a)), f"{i + 1}",
            color="white", fontsize=10, fontweight="bold", ha="center", va="center", zorder=4)
    # connector from wheel to card
    ox, oy = cx + R * np.cos(np.deg2rad(a)), cy + R * np.sin(np.deg2rad(a))
    x, y = pos[i]
    tx = min(max(ox, x), x + W); ty = min(max(oy, y), y + H)
    if i == 3:
        tx, ty = cx, y + H
    ax.plot([ox, tx], [oy, ty], color=COL[i], lw=1.0, ls=(0, (2, 1.5)), zorder=1)
    ax.add_patch(Circle((tx, ty), 0.55, fc=COL[i], ec="white", lw=0.6, zorder=5))
# clockwise arrow cue
th = np.linspace(np.deg2rad(150), np.deg2rad(30), 40)
ax.add_patch(Circle((cx, cy), R - w - 0.6, fc="white", ec=S.RULE, lw=0.6, zorder=3))
ax.text(cx, cy + 2.6, "Next-generation", ha="center", va="center", fontsize=7.2, fontweight="bold", color=S.INK, zorder=5)
ax.text(cx, cy, "explainable", ha="center", va="center", fontsize=7.2, fontweight="bold", color=S.INK, zorder=5)
ax.text(cx, cy - 2.6, "groundwater AI", ha="center", va="center", fontsize=7.2, fontweight="bold", color=S.INK, zorder=5)
ax.text(cx, 83.0, "test where you predict · explain what is stable · state what is uncertain", ha="center",
        va="center", fontsize=7.2, style="italic", color=S.MUTED)
ax.text(cx, 86.2, "From apparent accuracy to transferable, explainable skill", ha="center", va="center",
        fontsize=10, fontweight="bold", color=S.INK)

for ext in ["png", "pdf", "tiff"]:
    fig.savefig(f"{OUT}/Fig4_framework.{ext}",
                **({"pil_kwargs": {"compression": "tiff_lzw"}} if ext == "tiff" else {}))
print("ok")
