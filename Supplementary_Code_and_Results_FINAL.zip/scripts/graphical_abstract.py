"""Graphical abstract: apparent vs real accuracy, and the next-generation XAI framework."""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
import style as S

S.apply()
OUT = "/home/claude/data/figs"
rng = np.random.default_rng(3)

fig = plt.figure(figsize=(S.DOUBLE, 3.9))
fig.text(0.5, 0.955, "Groundwater AI: accuracy looks high until models predict where there are no data",
         ha="center", fontsize=9.5, fontweight="bold", color=S.INK)

# --- well-field schematics
def field(ax, mode):
    ax.set_xlim(0, 10); ax.set_ylim(0, 6); ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_color(S.RULE)
    ax.set_facecolor("#f6f5f2")
    # clustered wells
    centers = [(2, 4.4), (4.8, 2.0), (7.6, 4.0), (2.6, 1.5), (7.8, 1.4)]
    pts = np.vstack([c + rng.normal(0, 0.55, (14, 2)) for c in centers])
    pts = pts[(pts[:, 0] > 0.2) & (pts[:, 0] < 9.8) & (pts[:, 1] > 0.2) & (pts[:, 1] < 5.8)]
    if mode == "random":
        test = rng.random(len(pts)) < 0.2
    else:
        ax.add_patch(Rectangle((5.0, 0), 5, 3.0, fc="#fde7dc", ec=S.ORANGE, lw=0.8, ls=(0, (3, 2))))
        test = (pts[:, 0] > 5.0) & (pts[:, 1] < 3.0)
    ax.scatter(pts[~test, 0], pts[~test, 1], s=13, color=S.BLUE, edgecolor="white", lw=0.5, zorder=3)
    ax.scatter(pts[test, 0], pts[test, 1], s=16, color=S.ORANGE, edgecolor="white", lw=0.5,
               marker="s", zorder=4)


ax1 = fig.add_axes([0.03, 0.47, 0.2, 0.38]); field(ax1, "random")
ax1.set_title("Random testing", fontsize=7.5, color=S.INK, pad=3)
ax2 = fig.add_axes([0.03, 0.04, 0.2, 0.38]); field(ax2, "spatial")
ax2.set_title("Testing in unsampled regions", fontsize=7.5, color=S.INK, pad=3)
fig.text(0.03, 0.905, "■ test well   ● training well", fontsize=6, color=S.MUTED)

# --- result bars
ax = fig.add_axes([0.355, 0.17, 0.255, 0.66])
items = [("USA As", 0.55, 0.16), ("Araihazar As", 0.57, 0.23), ("Bangladesh As", 0.55, 0.35),
         ("USA F", 0.71, 0.56), ("Lower Indus F", 0.24, -1.10)]
for i, (lab, r, s) in enumerate(items[::-1]):
    ax.barh(i + 0.18, r, height=0.34, color=S.BLUE)
    ax.barh(i - 0.18, s, height=0.34, color=S.ORANGE)
    ax.text(r + 0.02, i + 0.18, f"{r:.2f}", va="center", fontsize=6, color=S.INK)
    ax.text(min(s, 0) - 0.03, i - 0.18, f"{s:.2f}", va="center", ha="right",
            fontsize=6, color=S.INK)
ax.axvline(0, color=S.MUTED, lw=0.6)
ax.set_yticks(range(len(items))); ax.set_yticklabels([t[0] for t in items[::-1]], fontsize=6.5, color=S.INK)
ax.set_xlim(-1.45, 0.9); ax.set_xticks([-1, -0.5, 0, 0.5]); ax.tick_params(axis="y", length=0)
ax.spines["left"].set_visible(False)
ax.set_xlabel("Cross-validated R²", fontsize=6.5)
ax.set_title("Skill falls 22–71%; some models\nbecome worse than the mean", fontsize=7.5, color=S.INK, pad=4)
fig.text(0.37, 0.035, "■ random test wells", fontsize=6.2, color=S.BLUE)
fig.text(0.515, 0.035, "■ held-out region", fontsize=6.2, color=S.ORANGE)

# --- key facts + framework
x0 = 0.645
facts = [("Predictor leakage", "chemistry from the same well\nlifts R² to 0.81 but cannot map"),
         ("Explainable AI", "SHAP rankings change between\ndistricts (ρ 0.75 → 0.28)"),
         ("Uncertainty", "90% intervals cover only\n72–84% in new regions"),
         ("Transfer", "Pakistan model flags 2% of\nTürkiye samples; 84% unsafe")]
for i, (h, t) in enumerate(facts):
    y = 0.70 - i * 0.165
    fig.patches.append(FancyBboxPatch((x0, y), 0.335, 0.145, boxstyle="round,pad=0,rounding_size=0.012",
                                      transform=fig.transFigure, fc="#f6f5f2", ec=S.RULE, lw=0.6))
    fig.text(x0 + 0.012, y + 0.105, h, fontsize=7, fontweight="bold", color=S.ORANGE, va="center")
    fig.text(x0 + 0.012, y + 0.045, t, fontsize=6.2, color=S.INK, va="center", linespacing=1.15)
fig.patches.append(FancyBboxPatch((x0, 0.03), 0.335, 0.12, boxstyle="round,pad=0,rounding_size=0.012",
                                  transform=fig.transFigure, fc="#e6f0fc", ec=S.BLUE, lw=0.8))
fig.text(x0 + 0.1675, 0.115, "Next-generation explainable AI", ha="center", fontsize=7, fontweight="bold", color=S.BLUE)
fig.text(x0 + 0.1675, 0.06, "mappable inputs · spatial validation · stable XAI\nregion-calibrated uncertainty · open data",
         ha="center", fontsize=6, color=S.INK, va="center", linespacing=1.2)
fig.text(x0 + 0.1675, 0.875, "6 datasets · 3 contaminants\n~117,000 wells · 4 countries",
         fontsize=6.4, color=S.MUTED, ha="center", linespacing=1.1)

for ext in ["png", "pdf", "tiff"]:
    fig.savefig(f"{OUT}/Graphical_abstract.{ext}",
                **({"pil_kwargs": {"compression": "tiff_lzw"}} if ext == "tiff" else {}))
print("ok")
