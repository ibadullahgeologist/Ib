"""Figure 3: from apparent accuracy to transferable skill — a five-stage framework."""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import style as S

S.apply()
OUT = "/home/claude/data/figs"

stages = [
    ("1  Data",
     "One campaign;\nnon-detects substituted\nsilently; kit steps\ntreated as continuous",
     "Report detection limits;\nmodel censoring; repeat\nseasons; dense enough\nfor local variability",
     "Non-detects 23–43%;\n2 of 21 sites switch\nsafe/unsafe by season"),
    ("2  Predictors",
     "Co-measured chemistry\nand raw coordinates\nas inputs",
     "Only inputs known at\nunsampled sites:\ngeology, terrain,\nclimate, well depth",
     "Bangladesh As R²\n0.81 with chemistry\nvs 0.55 mappable only"),
    ("3  Validation",
     "Random k-fold\ncross-validation",
     "Spatial blocks,\nleave-region-out and\nan external basin",
     "USA As R² 0.55 → 0.16;\nPakistan As AUC 0.86\n→ 0.59 (new district)\n→ 0.43 (Türkiye)"),
    ("4  Explanation",
     "One SHAP ranking\nread as the\nprocess drivers",
     "Check ranking stability\nacross regions; test\nagainst geochemistry",
     "Pakistan F ranking\nagreement\nρ 0.75 → 0.28"),
    ("5  Uncertainty and\n    reporting",
     "One best-guess map;\nsuccesses only",
     "Region-calibrated\nintervals; area of\napplicability;\nreport failures",
     "Nominal 90% intervals\ncover 72–84% of wells\nin new regions"),
]

fig, ax = plt.subplots(figsize=(S.DOUBLE, 3.6))
ax.set_xlim(0, 100); ax.set_ylim(0, 56); ax.axis("off")
n = len(stages)
gap, left = 1.4, 14.0
w = (100 - left - gap * (n - 1)) / n
rows = {"head": (49.0, 6.0), "old": (35.0, 11.0), "new": (18.0, 14.0), "ev": (1.5, 13.5)}
labels = {"old": ("Common practice", S.MUTED), "new": ("Next-generation\npractice", S.BLUE),
          "ev": ("Evidence from\nthis study", S.ORANGE)}
for key, (txt, c) in labels.items():
    y, h = rows[key]
    ax.text(left - 1.0, y + h / 2, txt, ha="right", va="center", fontsize=6.5,
            color=c, fontweight="bold")

for i, (head, old, new, ev) in enumerate(stages):
    x = left + i * (w + gap)
    y, h = rows["head"]
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.2",
                                fc=S.INK, ec="none"))
    ax.text(x + w / 2, y + h / 2, head, ha="center", va="center", fontsize=7,
            color="white", fontweight="bold", linespacing=1.0)
    y, h = rows["old"]
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.2",
                                fc="#f1f0ec", ec=S.RULE, lw=0.6))
    ax.text(x + w / 2, y + h / 2, old, ha="center", va="center", fontsize=5.8,
            color=S.MUTED, linespacing=1.25)
    y, h = rows["new"]
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.2",
                                fc="#e6f0fc", ec=S.BLUE, lw=0.8))
    ax.text(x + w / 2, y + h / 2, new, ha="center", va="center", fontsize=5.8,
            color=S.INK, linespacing=1.25)
    y, h = rows["ev"]
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.2",
                                fc="white", ec=S.ORANGE, lw=0.8, ls=(0, (3, 1.5))))
    ax.text(x + w / 2, y + h / 2, ev, ha="center", va="center", fontsize=5.8,
            color=S.INK, linespacing=1.25)
    # old -> new arrow
    ax.add_patch(FancyArrowPatch((x + w / 2, rows["old"][0] - 0.2),
                                 (x + w / 2, rows["new"][0] + rows["new"][1] + 0.2),
                                 arrowstyle="-|>", mutation_scale=7, color=S.BLUE, lw=0.9))
    if i < n - 1:
        yh = rows["head"][0] + rows["head"][1] / 2
        ax.add_patch(FancyArrowPatch((x + w + 0.1, yh), (x + w + gap - 0.1, yh),
                                     arrowstyle="-|>", mutation_scale=6, color=S.INK, lw=0.8))
fig.subplots_adjust(left=0.01, right=0.995, top=0.99, bottom=0.01)
for ext in ["png", "pdf", "tiff"]:
    fig.savefig(f"{OUT}/Fig3_framework.{ext}",
                **({"pil_kwargs": {"compression": "tiff_lzw"}} if ext == "tiff" else {}))
print("ok")
