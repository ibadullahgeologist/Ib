"""Pakistan (Lower Indus, Sindh) random vs spatial CV.

Arsenic values are semi-quantitative steps (0, 5, 10, 25, 50 ...) with 82% zeros,
so arsenic is modelled as exceedance of 10 ug/L (classifier, ROC-AUC).
Fluoride is continuous and modelled as log10(F + 0.01) (regressor, R2).
"""
import numpy as np
import pandas as pd
from pyproj import Transformer
from sklearn.model_selection import StratifiedKFold, KFold, GroupKFold
from sklearn.metrics import roc_auc_score, r2_score
from xgboost import XGBClassifier, XGBRegressor

p = pd.read_excel("/home/claude/data/pakistan/pak.xlsx")
t = Transformer.from_crs("EPSG:4326", "EPSG:32642", always_xy=True)  # UTM 42N
x, y = t.transform(p.Longitude.values, p.Latitude.values)
p["x_km"], p["y_km"] = np.asarray(x) / 1000, np.asarray(y) / 1000
p["depth"] = p["Well Depth (ft)"] * 0.3048
CHEM = ["EC (uS/cm)", "pH", "HCO3 (mg/l)", "Cl (mg/l)", "SO4 (mg/l)", "Ca (mg/l)",
        "Mg (mg/l)", "Na (mg/l)", "K (mg/l)", "NO3 (mg/l)", "PO4 (mg/l)", "Fe (mg/l)"]
FEATS = {"location+depth": ["x_km", "y_km", "depth"],
         "+co-measured chem": ["x_km", "y_km", "depth"] + CHEM}
SEEDS = range(5)


def folds_for(kind, seed, yv):
    if kind == "random":
        return list((StratifiedKFold if yv.dtype == int else KFold)(
            5, shuffle=True, random_state=seed).split(p, yv))
    if kind == "district":
        return list(GroupKFold(p.District.nunique()).split(p, yv, p.District))
    b = kind
    g = (np.floor(p.x_km / b).astype(int).astype(str) + "_" +
         np.floor(p.y_km / b).astype(int).astype(str)).values
    ug = np.unique(g)
    fo = dict(zip(ug, np.random.default_rng(seed).integers(0, 5, len(ug))))
    return list(GroupKFold(5).split(p, yv, np.array([fo[v] for v in g])))


def run(target):
    rows = []
    if target == "As>10":
        yv = (p["As µg"] > 10).astype(int).values
    else:
        yv = np.log10(p["F (mg/l)"].values + 0.01)
    for fs, cols in FEATS.items():
        X = p[cols].astype(float)
        for kind in ["random", 10, 25, 50, "district"]:
            for s in (SEEDS if kind != "district" else [0]):
                pred = np.zeros(len(yv))
                for tr, te in folds_for(kind, s, yv):
                    if target == "As>10":
                        m = XGBClassifier(n_estimators=300, max_depth=4,
                                          learning_rate=0.05, subsample=0.8,
                                          colsample_bytree=0.8, random_state=s)
                        m.fit(X.iloc[tr], yv[tr])
                        pred[te] = m.predict_proba(X.iloc[te])[:, 1]
                    else:
                        m = XGBRegressor(n_estimators=300, max_depth=4,
                                         learning_rate=0.05, subsample=0.8,
                                         colsample_bytree=0.8, random_state=s)
                        m.fit(X.iloc[tr], yv[tr])
                        pred[te] = m.predict(X.iloc[te])
                score = (roc_auc_score(yv, pred) if target == "As>10"
                         else r2_score(yv, pred))
                rows.append(dict(target=target, features=fs, cv=str(kind),
                                 seed=s, score=score))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    res = pd.concat([run("As>10"), run("F")])
    res.to_csv("/home/claude/data/results/cv_pakistan.csv", index=False)
    print(res.groupby(["target", "features", "cv"], sort=False)
          .score.agg(["mean", "std"]).round(3).to_string())
