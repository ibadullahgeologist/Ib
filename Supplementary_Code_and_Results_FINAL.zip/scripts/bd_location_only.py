"""Bangladesh national arsenic with mappable predictors only (location + depth)."""
import numpy as np, pandas as pd
from sklearn.model_selection import KFold, GroupKFold
from load_data import bangladesh_national
from cv_experiment import run_cv
df, _ = bangladesh_national()
y = np.log10(df.target.clip(lower=0).values + 1); guide = 11
X = df[["depth", "x_km", "y_km"]].astype(float)
rows = []
for s in [0, 1, 2]:
    r2, auc = run_cv(X, y, guide, KFold(5, shuffle=True, random_state=s), seed=s)
    rows.append(dict(cv="random", block_km=0, seed=s, r2=r2, auc=auc))
    for b in [10, 25, 50, 100]:
        g = (np.floor(df.x_km / b).astype(int).astype(str) + "_" + np.floor(df.y_km / b).astype(int).astype(str)).values
        ug = np.unique(g); fo = dict(zip(ug, np.random.default_rng(s).integers(0, 5, len(ug))))
        r2, auc = run_cv(X, y, guide, GroupKFold(5), groups=np.array([fo[v] for v in g]), seed=s)
        rows.append(dict(cv="spatial", block_km=b, seed=s, r2=r2, auc=auc))
out = pd.DataFrame(rows); out.to_csv("/home/claude/data/results/cv_bangladesh_location_only.csv", index=False)
print(out.groupby(["cv", "block_km"])[["r2", "auc"]].mean().round(3))
