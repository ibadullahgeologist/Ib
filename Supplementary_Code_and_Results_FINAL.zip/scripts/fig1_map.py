"""Figure 1: study areas on shaded-relief basemaps (Nature-style)."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from mpl_toolkits.basemap import Basemap
from pyproj import Transformer
import style as S
import load_data as ld

S.apply()
OUT = "/home/claude/data/figs"

p = pd.read_excel("/home/claude/data/pakistan/pak.xlsx")
t = pd.read_excel("/home/claude/data/turkey/tur.xlsx", "Analysis_Ready")
lon_t, lat_t = Transformer.from_crs("EPSG:32636", "EPSG:4326", always_xy=True)\
    .transform(t.Easting_m.values, t.Northing_m.values)
t["lon"], t["lat"] = lon_t, lat_t
bdn, _ = ld.bangladesh_national()
ara, _ = ld.bangladesh_araihazar()
usf, _ = ld.usa_fluoride()
usa_site = pd.read_csv("/home/claude/data/usgs_as/Site_Information.csv")
lon_u, lat_u = Transformer.from_crs("EPSG:5070", "EPSG:4326", always_xy=True)\
    .transform(usa_site.XCoord.values, usa_site.YCoord.values)

CL = ["#bdbdbd", "#fdae6b", "#e6550d", "#7f2704"]
LAB = ["≤ 10", "10–50", "50–100", "> 100"]


from PIL import Image
import mpl_toolkits.basemap_data as _bd, os as _os
Image.MAX_IMAGE_PIXELS = None
_REL = np.asarray(Image.open(_os.path.join(list(_bd.__path__)[0], "shadedrelief.jpg"))).astype(float) / 255.0


def smooth_relief(m, ax, alpha=0.85, nx=900):
    """Shaded relief cropped to the map and bilinearly resampled (no pixel blocks)."""
    H, W, _ = _REL.shape
    lons = np.linspace(-180, 180, W, endpoint=False) + 180 / W
    lats = np.linspace(90, -90, H, endpoint=False) - 90 / H
    i0 = max(int((90 - m.urcrnrlat) / 180 * H) - 3, 0); i1 = min(int((90 - m.llcrnrlat) / 180 * H) + 3, H)
    j0 = max(int((m.llcrnrlon + 180) / 360 * W) - 3, 0); j1 = min(int((m.urcrnrlon + 180) / 360 * W) + 3, W)
    sub = _REL[i0:i1, j0:j1][::-1]
    la, lo = lats[i0:i1][::-1], lons[j0:j1]
    ny = int(nx * (m.ymax - m.ymin) / (m.xmax - m.xmin))
    rgb = np.dstack([m.transform_scalar(sub[..., c], lo, la, nx, ny, order=1) for c in range(3)])
    m.imshow(np.clip(rgb, 0, 1), ax=ax, alpha=alpha, interpolation="bilinear", zorder=0)


def as_class(v):
    return np.digitize(v, [10, 50, 100], right=True)


def scalebar(m, ax, lon, lat, km, label=None):
    """Simple km scale bar starting at (lon, lat)."""
    x0, y0 = m(lon, lat)
    dlon = km / (111.32 * np.cos(np.deg2rad(lat)))
    x1, _ = m(lon + dlon, lat)
    ax.plot([x0, x1], [y0, y0], color="k", lw=2.2, solid_capstyle="butt", zorder=20)
    ax.plot([x0, (x0 + x1) / 2], [y0, y0], color="white", lw=1.0, solid_capstyle="butt", zorder=21)
    ax.text((x0 + x1) / 2, y0, (label or f"{km} km") + "\n", ha="center", va="bottom",
            fontsize=6, zorder=21)


def north(ax, x=0.94, y=0.86):
    ax.annotate("N", xy=(x, y + 0.08), xytext=(x, y), xycoords="axes fraction",
                ha="center", va="center", fontsize=7, fontweight="bold",
                arrowprops=dict(arrowstyle="-|>", color="k", lw=0.8), zorder=30)


fig = plt.figure(figsize=(S.DOUBLE, 6.8))
gs = fig.add_gridspec(2, 2, height_ratios=[0.78, 1.25], hspace=0.22, wspace=0.10)

# ---------------------------------------------------------------- (a) global
ax = fig.add_subplot(gs[0, :])
m = Basemap(projection="cyl", llcrnrlon=-128, urcrnrlon=100, llcrnrlat=6, urcrnrlat=58,
            resolution="l", ax=ax)
m.shadedrelief(scale=0.35, alpha=0.75)
m.drawcountries(color="#7a7a7a", linewidth=0.3)
m.drawcoastlines(color="#555555", linewidth=0.35)
m.drawparallels([15, 30, 45], labels=[1, 0, 0, 0], linewidth=0.2, color="#8a8a8a", fontsize=6, dashes=[1, 2])
m.drawmeridians([-120, -90, -60, -30, 0, 30, 60, 90], labels=[0, 0, 0, 1], linewidth=0.2,
                color="#8a8a8a", fontsize=6, dashes=[1, 2])
sets = [("USA arsenic, USGS (n = 67,676)", lon_u, lat_u, S.BLUE, 0.35),
        ("USA fluoride, USGS (n = 38,105)", usf.lon.values, usf.lat.values, S.AQUA, 0.35),
        ("Bangladesh arsenic, BGS/DPHE (n = 3,534)", bdn.lon.values, bdn.lat.values, S.VIOLET, 0.9),
        ("Bangladesh, Araihazar arsenic (n = 6,595)", ara.lon.values, ara.lat.values, S.MAGENTA, 0.9),
        ("Pakistan, Lower Indus: As, F, NO$_3$ (this study, n = 848)", p.Longitude.values, p.Latitude.values, S.ORANGE, 0.9),
        ("Türkiye, Kazan Basin: As (this study, n = 59)", lon_t, lat_t, S.YELLOW, 0.9)]
handles = []
for lab, lo, la, c, sz in sets:
    ok = np.isfinite(lo) & np.isfinite(la)
    x, y = m(lo[ok], la[ok])
    ax.scatter(x, y, s=sz, color=c, lw=0, alpha=0.85, rasterized=True, zorder=5)
    handles.append(Line2D([], [], marker="o", ls="", color=c, ms=4.5, label=lab))
for (lo, la, c, lab) in [(68.9, 26.1, S.ORANGE, "b"), (32.65, 40.15, S.YELLOW, "c"), (90.4, 23.8, S.MAGENTA, "")]:
    x, y = m(lo, la)
    ax.scatter(x, y, s=95, facecolor="none", edgecolor="k", lw=0.9, zorder=6)
    if lab:
        ax.text(x + 3.2, y + 3.2, lab, fontsize=7.5, fontweight="bold", zorder=7)
ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.07), ncol=3,
          fontsize=6.2, handletextpad=0.2, columnspacing=1.0)
S.panel(ax, "a", x=-0.05, y=1.0)

# ---------------------------------------------------------------- (b) Lower Indus
ax = fig.add_subplot(gs[1, 0])
m = Basemap(projection="merc", llcrnrlon=66.6, urcrnrlon=71.4, llcrnrlat=23.55, urcrnrlat=28.75,
            resolution="i", ax=ax)
smooth_relief(m, ax, alpha=0.9)
m.drawcountries(color="#333333", linewidth=0.7)
m.drawcoastlines(color="#4a4a4a", linewidth=0.4)
m.drawrivers(color="#2b7bba", linewidth=0.8)
m.drawparallels([24, 25, 26, 27, 28], labels=[1, 0, 0, 0], linewidth=0.2, color="#7a7a7a", fontsize=6, dashes=[1, 2])
m.drawmeridians([67, 68, 69, 70, 71], labels=[0, 0, 0, 1], linewidth=0.2, color="#7a7a7a", fontsize=6, dashes=[1, 2])
cl = as_class(p["As µg"].values)
for k in range(4):
    sel = cl == k
    x, y = m(p.Longitude.values[sel], p.Latitude.values[sel])
    ax.scatter(x, y, s=4 if k == 0 else 12, color=CL[k], edgecolor="k" if k else "none",
               lw=0.25, zorder=10 + k)
# district labels at sample centroids
cent = p.groupby("District")[["Longitude", "Latitude"]].mean()
short = {"Kamber Shahdadkot": "Kamber Shahdadkot", "Tando Muhammad Khan": "T. M. Khan",
         "Tando Allahyar": "T. Allahyar", "Naushahro Feroze": "N. Feroze"}
offs = {"Jacobabad": (0.0, 0.18), "Kashmore": (0.15, 0.15), "Ghotki": (0.1, 0.18), "Sukkur": (0.15, -0.1),
        "Kamber Shahdadkot": (-0.2, 0.25), "Naushahro Feroze": (-0.55, 0.0), "Nawabshah": (0.4, 0.1),
        "Matiari": (-0.55, 0.05), "Tando Allahyar": (0.35, 0.15), "Tando Muhammad Khan": (-0.6, -0.1),
        "Mirpurkhas": (0.35, 0.15), "Badin": (0.1, -0.35), "Thatta": (-0.15, -0.3), "Tharparkar": (0.2, -0.25)}
for dname, r in cent.iterrows():
    dx, dy = offs.get(dname, (0, 0.15))
    x, y = m(r.Longitude + dx, r.Latitude + dy)
    ax.text(x, y, short.get(dname, dname), fontsize=5.2, ha="center", va="center", zorder=25,
            color="#111111", style="italic",
            bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none", alpha=0.65))
x, y = m(66.95, 24.45)
ax.text(x, y, "Arabian\nSea", fontsize=6, color="#1f5f99", ha="center", style="italic", zorder=25)
x, y = m(70.9, 25.6)
ax.text(x, y, "INDIA", fontsize=6, color="#333333", ha="center", zorder=25)
x, y = m(67.5, 27.95)
ax.text(x, y, "Indus", fontsize=6, color="#1f5f99", style="italic", zorder=25, rotation=-60)
scalebar(m, ax, 70.05, 23.8, 100)
north(ax)
ax.set_title("Lower Indus Basin, Sindh, Pakistan", fontsize=7.6, loc="left")
S.panel(ax, "b", x=-0.1, y=1.02)

# ---------------------------------------------------------------- (c) Kazan Basin
ax = fig.add_subplot(gs[1, 1])
lo0, lo1, la0, la1 = 32.36, 32.94, 39.93, 40.42
m = Basemap(projection="merc", llcrnrlon=lo0, urcrnrlon=lo1, llcrnrlat=la0, urcrnrlat=la1,
            resolution="i", ax=ax)
m.drawmapboundary(fill_color="#f2efe6", color="k", linewidth=0.6)
m.drawparallels([40.0, 40.1, 40.2, 40.3, 40.4], labels=[1, 0, 0, 0], linewidth=0.25, color="#8a8a8a", fontsize=6, dashes=[1, 2])
m.drawmeridians([32.5, 32.6, 32.7, 32.8], labels=[0, 0, 0, 1], linewidth=0.25, color="#8a8a8a", fontsize=6, dashes=[1, 2])
clt = as_class(t.As_ug_L.values)
for season, mk in [("Dry", "o"), ("Wet", "^")]:
    for k in range(4):
        sel = (clt == k) & (t.Season.values == season)
        x, y = m(t.lon.values[sel], t.lat.values[sel])
        ax.scatter(x, y, s=24, marker=mk, color=CL[k], edgecolor="k", lw=0.35, zorder=10 + k, alpha=0.95)
for name, lo, la, dx, dy, ha in [("Kahramankazan", 32.683, 40.207, 0.012, -0.022, "left"),
                                 ("Ankara (center) ↘", 32.86, 39.965, -0.01, 0.012, "right")]:
    x, y = m(lo, la)
    ax.plot(x, y, marker="s", color="k", ms=3, zorder=20)
    x, y = m(lo + dx, la + dy)
    ax.text(x, y, name, fontsize=6.2, ha=ha, zorder=21,
            bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none", alpha=0.75))
scalebar(m, ax, lo0 + 0.03, la0 + 0.025, 10)
north(ax, x=0.94, y=0.84)
ax.set_title("Kazan Basin, Ankara, Türkiye", fontsize=7.6, loc="left")
S.panel(ax, "c", x=-0.1, y=1.02)
# locator inset with relief
ia = ax.inset_axes([0.015, 0.70, 0.40, 0.29])
mi = Basemap(projection="merc", llcrnrlon=25.5, urcrnrlon=45.0, llcrnrlat=35.5, urcrnrlat=42.4,
             resolution="l", ax=ia)
mi.shadedrelief(scale=0.6)
mi.drawcountries(color="#555555", linewidth=0.3)
mi.drawcoastlines(color="#555555", linewidth=0.3)
x0, y0 = mi(lo0, la0); x1, y1 = mi(lo1, la1)
ia.add_patch(plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, ec="red", lw=0.9, zorder=10))
xa, ya = mi(32.85, 39.93)
ia.plot(xa, ya, "ks", ms=1.8, zorder=11)
for s_ in ia.spines.values():
    s_.set_visible(True); s_.set_color("k"); s_.set_linewidth(0.5)

h = [Line2D([], [], marker="o", ls="", color=CL[k], mec="k", mew=0.3, ms=5, label=f"{LAB[k]} µg L$^{{-1}}$") for k in range(4)]
h += [Line2D([], [], marker="o", ls="", color="white", mec="k", ms=4.5, label="dry (Oct 2021)"),
      Line2D([], [], marker="^", ls="", color="white", mec="k", ms=4.5, label="wet (Apr 2022)")]
fig.legend(handles=h, loc="lower center", ncol=6, bbox_to_anchor=(0.5, 0.0),
           title="Arsenic (b, c); sampling season (c)", title_fontsize=6.4, fontsize=6.2,
           columnspacing=1.0, handletextpad=0.2)
fig.subplots_adjust(left=0.06, right=0.985, top=0.975, bottom=0.085)
for ext in ["png", "pdf", "tiff"]:
    fig.savefig(f"{OUT}/Fig1_study_areas.{ext}", dpi=600,
                **({"pil_kwargs": {"compression": "tiff_lzw"}} if ext == "tiff" else {}))
print("ok")
