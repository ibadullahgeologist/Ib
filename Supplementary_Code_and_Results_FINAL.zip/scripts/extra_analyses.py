"""Supplementary analyses:
 A. SHAP: share of model attribution taken by location (x, y) and the stability
    of feature-importance rankings across random vs spatial training folds.
 B. Split-conformal 90% prediction intervals: coverage for randomly held-out
    wells vs wells in held-out regions.
 C. Censoring sensitivity (USA As): substitute non-detects with DL, DL/2, 0.
Writes CSVs to results/.
"""
import numpy as np
import pandas as pd
import shap
from scipy.stats import spearmanr
from sklearn.model_selection import KFold, GroupKFold
from sklearn.metrics import r2_score
from xgboost import XGBRegressor
import load_data as ld
import pakistan_cv as pc

RES = "/home/claude/data/results"
rng0 = np.random.default_rng(42)


def xgb(seed=0):
    return XGBRegressor(n_estimators=300, max_depth=5, learning_rate=0.05,
                        subsample=0.8, colsample_bytree=0.8, n_jobs=-1,
                        random_state=seed, tree_method="hist")


def blocks(df, b, seed=0, k=5):
    g = (np.floor(df.x_km / b).astype(int).astype(str) + "_" +
         np.floor(df.y_km / b).astype(int).astype(str)).values
    ug = np.unique(g)
    fo = dict(zip(ug, np.random.default_rng(seed).integers(0, k, len(ug))))
    return np.array([fo[v] for v in g])


def datasets():
    """name -> (df, feature list, y, spatial group labels, group label name)"""
    out = {}
    p = pc.p.copy()
    chem = [c for c in pc.CHEM]
    p["district"] = p.District
    out["Pakistan F"] = (p, ["x_km", "y_km", "depth"] + chem,
                         np.log10(p["F (mg/l)"].values + 0.01),
                         p.District.values, "district")
    p2 = p.copy()
    out["Pakistan NO3"] = (p2, ["x_km", "y_km", "depth"] +
                           [c for c in chem if c != "NO3 (mg/l)"],
                           np.log10(p2["NO3 (mg/l)"].values + 0.1),
                           p2.District.values, "district")
    for name, f, b, extra in [
            ("Bangladesh national As", ld.bangladesh_national, 100, False),
            ("Araihazar As", ld.bangladesh_araihazar, 2, False),
            ("USA As", ld.usa_arsenic, 400, False),
            ("USA F", ld.usa_fluoride, 400, False)]:
        df, feats = f()
        df = df.reset_index(drop=True)
        sp = name.split()[-1]
        cols = (["x_km", "y_km"] + ["depth"]) if name.startswith("Bangladesh") \
            else feats + ["x_km", "y_km"]
        y = np.log10(df.target.clip(lower=0).values + (1 if sp == "As" else 0.01))
        out[name] = (df, cols, y, blocks(df, b), f"{b} km blocks")
    return out


def shap_analysis(D):
    rows = []
    for name, (df, cols, y, groups, gname) in D.items():
        X = df[cols].astype(float).reset_index(drop=True)
        n = min(len(X), 3000)
        idx = rng0.choice(len(X), n, replace=False)
        for scheme in ["random", "spatial"]:
            if scheme == "random":
                splits = KFold(5, shuffle=True, random_state=0).split(X)
            else:
                ug = np.unique(groups)
                k = min(5, len(ug))
                splits = GroupKFold(k).split(X, y, groups)
            imps = []
            for tr, _ in splits:
                m = xgb().fit(X.iloc[tr], y[tr])
                sv = shap.TreeExplainer(m).shap_values(X.iloc[idx])
                imps.append(np.abs(sv).mean(0))
            imps = np.array(imps)
            share_loc = (imps[:, [cols.index("x_km"), cols.index("y_km")]].sum(1)
                         / imps.sum(1))
            rhos = [spearmanr(imps[i], imps[j])[0]
                    for i in range(len(imps)) for j in range(i + 1, len(imps))]
            top = [cols[int(np.argmax(r))] for r in imps]
            rows.append(dict(dataset=name, scheme=scheme, n_features=len(cols),
                             location_share=share_loc.mean(),
                             rank_rho_mean=np.mean(rhos), rank_rho_min=np.min(rhos),
                             top_feature_per_fold="; ".join(top),
                             n_distinct_top=len(set(top))))
            print(rows[-1], flush=True)
            if scheme == "random":
                mean_imp = imps.mean(0)
                pd.DataFrame({"feature": cols, "mean_abs_shap": mean_imp}).to_csv(
                    f"{RES}/shap_importance_{name.replace(' ', '_')}.csv",
                    index=False)
    pd.DataFrame(rows).to_csv(f"{RES}/shap_stability.csv", index=False)


def conformal(D, alpha=0.1):
    rows = []
    for name, (df, cols, y, groups, gname) in D.items():
        X = df[cols].astype(float).reset_index(drop=True)
        for scheme in ["random", "spatial"]:
            cov, wid = [], []
            for seed in range(3):
                if scheme == "random":
                    splits = KFold(5, shuffle=True, random_state=seed).split(X)
                else:
                    ug = np.random.default_rng(seed).permutation(np.unique(groups))
                    fo = {g: i % 5 for i, g in enumerate(ug)}  # every fold used
                    fg = np.array([fo[v] for v in groups])
                    splits = GroupKFold(5).split(X, y, fg)
                for tr, te in splits:
                    if len(te) == 0:
                        continue
                    r = np.random.default_rng(seed).permutation(tr)
                    cal, fit = r[: len(r) // 4], r[len(r) // 4:]
                    m = xgb(seed).fit(X.iloc[fit], y[fit])
                    res = np.abs(y[cal] - m.predict(X.iloc[cal]))
                    q = np.quantile(res, np.ceil((len(cal) + 1) * (1 - alpha))
                                    / len(cal), method="higher")
                    pr = m.predict(X.iloc[te])
                    cov.append(np.mean(np.abs(y[te] - pr) <= q))
                    wid.append(2 * q)
            rows.append(dict(dataset=name, scheme=scheme, test_unit=(
                "random wells" if scheme == "random" else gname),
                coverage_mean=np.mean(cov), coverage_min=np.min(cov),
                coverage_max=np.max(cov), width_log10=np.mean(wid)))
            print(rows[-1], flush=True)
    pd.DataFrame(rows).to_csv(f"{RES}/conformal_coverage.csv", index=False)


def censoring():
    df, feats = ld.usa_arsenic()
    df = df.reset_index(drop=True)
    cols = feats + ["x_km", "y_km"]
    X = df[cols].astype(float)
    g = blocks(df, 400)
    rows = []
    for rule, fac in [("DL", 1.0), ("DL/2", 0.5), ("zero", 0.0)]:
        t = df.target.clip(lower=0).values.copy()
        t[df.censored.values] = t[df.censored.values] * fac
        y = np.log10(t + 1)
        for scheme in ["random", "spatial"]:
            sp = (KFold(5, shuffle=True, random_state=0).split(X) if scheme ==
                  "random" else GroupKFold(5).split(X, y, g))
            pr = np.zeros(len(y))
            for tr, te in sp:
                pr[te] = xgb().fit(X.iloc[tr], y[tr]).predict(X.iloc[te])
            rows.append(dict(rule=rule, scheme=scheme, r2=r2_score(y, pr)))
            print(rows[-1], flush=True)
    rl = df.loc[df.censored, "target"]
    pd.DataFrame(rows).to_csv(f"{RES}/censoring_sensitivity.csv", index=False)
    rl.value_counts().rename_axis("reporting_limit_ugL").reset_index(
        name="n_wells").to_csv(f"{RES}/usa_as_reporting_limits.csv", index=False)


if __name__ == "__main__":
    import sys
    D = datasets()
    which = sys.argv[1:] or ["shap", "conformal", "censoring"]
    if "shap" in which:
        shap_analysis(D)
    if "conformal" in which:
        conformal(D)
    if "censoring" in which:
        censoring()
